package SlidingWindow;


import java.util.Map;

/**  1456. Maximum Number of Vowels in a Substring of Given Length :
 *   Given a string s and an integer k, return the maximum number of vowel
 *   letters in any substring of s with length k.
 *   Vowel letters in English are 'a', 'e', 'i', 'o', and 'u'.
 */
public class MaximumNumberVowelsOfSubstring {
    public static void main(String[] args) {
        String s = "abciiidef";
        int k = 3;
        System.out.println(maxVowels(s, k)); // Output: 3
    }

    private static int maxVowels(String s, int k) {
        char[] chars = s.toCharArray();
//        Map<Character, Boolean> vowelsMap = Map.of(
//                'a', true,
//                'e', true,
//                'i', true,
//                'o', true,
//                'u', true
//        );

        int maxVowels;
        int currentVowels = 0;
        for(int i = 0; i < k; i++){
            if(isVowel(chars[i])){
                currentVowels++;
            }
        }
        maxVowels = currentVowels;
        for (int i = k; i < chars.length; i++){
            if(isVowel(chars[i])){
                currentVowels++;
            }
            if(isVowel(chars[i - k])){
                currentVowels--;
            }
            maxVowels = Math.max(maxVowels, currentVowels);
        }
        System.out.println("Current Vowels = " + maxVowels);
        return maxVowels;
    }

    private static boolean isVowel(char c) {
        c = Character.toLowerCase(c);
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            return true;
        }
        return false;
    }

}
