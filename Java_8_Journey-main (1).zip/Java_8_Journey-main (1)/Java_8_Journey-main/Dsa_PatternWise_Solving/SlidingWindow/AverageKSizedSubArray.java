package SlidingWindow;

public class AverageKSizedSubArray {
    public static void main(String[] args) {
        int[] arr = {2,1,5,1,3,2,0,9};
        findAverageSubArray(arr,3);
    }

    private static void findAverageSubArray(int[] arr, int i) {
        int sum = 0;
        for(int j=0;j<i;j++)
            sum += arr[j];

        double average = (double)sum/i;
        System.out.println("Average of first "+i+" elements = "+average);

        for(int j=i;j<arr.length;j++){
            sum += arr[j];
            sum -= arr[j-i];
            average = (double)sum/i;
            System.out.println("Average of elements from index "+(j-i+1)+" to "+j+" = "+average);
        }
    }
}
