package SlidingWindow;

public class MaxSumSubArraySum {
    public static void main(String[] args) {
        int[] arr = {2,1,5,1,3,2,0,9};
        findMaxSubArray2(arr,3);
    }

    private static void findMaxSubArray(int[] arr, int k) {
        int sum =0;
        int maxSum = Integer.MIN_VALUE;
        int i =0,j=0;
        while(j < arr.length){
            if (j == i + k){
                i+=1;
                j=i;
                maxSum = Math.max(sum, maxSum);
                sum=0;
            }
            sum += arr[j];
            j++;
        }
        System.out.println("Max Sum = "+Math.max(sum,maxSum));
    }

    private static void findMaxSubArray2(int[] arr, int k) {
        int sum = 0;

        for(int i=0;i<k;i++)
            sum += arr[i];

        int max = sum;

        for(int i=k;i<arr.length;i++){
            sum += arr[i];
            sum -= arr[i-k];
            max = Math.max(max,sum);
        }

        System.out.println("Max Sum = "+max);
    }

}
