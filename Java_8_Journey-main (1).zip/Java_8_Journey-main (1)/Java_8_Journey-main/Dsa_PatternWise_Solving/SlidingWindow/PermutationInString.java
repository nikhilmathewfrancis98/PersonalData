package SlidingWindow;

import java.util.Arrays;
import java.util.Map;

/**
 Given two strings s1 and s2, return true if s2 contains a permutation of s1,
 or false otherwise. In other words, return true if one of s1's
 permutations is the substring of s2.
 */
public class PermutationInString {
    public static void main(String[] args) {
        String s1 = "ab";
        String s2 = "eidbaooo";
        System.out.println(checkInclusion1(s1, s2)); // Output: true
    }

    // 3 approaches 1: Brute Force / sort the string then compare,
    // 2: Sliding Window, 3: Sliding Window with HashMap
    private static boolean checkInclusion(String s1, String s2) {
        int windowSize = s1.length();
        Map<Character, Integer> s1CharCount = new java.util.HashMap<>();
        for (char c : s1.toCharArray()) {
            s1CharCount.put(c, s1CharCount.getOrDefault(c, 0) + 1);
        }
        int j=0;
        Map<Character, Integer> windowCharCount = new java.util.HashMap<>();
        for (int i = 0; i < s2.length(); i++) {
            char c = s2.charAt(i);
            windowCharCount.put(c, windowCharCount.getOrDefault(c, 0) + 1);
            if (i - j + 1 > windowSize) {
                char leftChar = s2.charAt(j);
                windowCharCount.put(leftChar, windowCharCount.get(leftChar) - 1);
                if (windowCharCount.get(leftChar) == 0) {
                    windowCharCount.remove(leftChar);
                }
                j++;
            }
            if (windowCharCount.equals(s1CharCount)) {
                return true;
            }

        }
        return false;
    }
    private static boolean checkInclusion2(String s1, String s2) {
        int windowSize = s1.length();
        for (int i = 0; i <= s2.length() - windowSize; i++) {
            String subString = s2.substring(i, i + windowSize);
            if (isPermutation(s1, subString)) {
                return true;
            }
        }
        return false;
    }
    private static boolean checkInclusion1(String s1, String s2) {
        int[] arr = new int[26];
        int st1=s1.length();
        int st2=s2.length();
        if(st1>st2)
            return false;
        for(int i=0; i<st1; i++){
            arr[s1.charAt(i)-'a']++;
        }
        int[] arr2 = new int[26];
        for(int i=0; i<st1; i++){
            arr2[s2.charAt(i)-'a']++;
        }
        Arrays.stream(arr2).forEach(System.out::print);
        System.out.println("/n");
        Arrays.stream(arr).forEach(System.out::print);
        return java.util.Arrays.equals(arr, arr2);
    }

    private static boolean isPermutation(String s1, String subString) {
        char[] s1Chars = s1.toCharArray();
        char[] subStringChars = subString.toCharArray();
        java.util.Arrays.sort(s1Chars);
        java.util.Arrays.sort(subStringChars);
        return java.util.Arrays.equals(s1Chars, subStringChars);
    }
}
