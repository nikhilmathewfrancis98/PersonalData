package main.java.com;

public class Volatile {
    private static volatile boolean flag = true;
    public static void stop(){
        flag = false;
        System.out.println("Stopping...");
    }
    public static void run(){
       while(flag){
           System.out.println("Running...");
       }
    }
    public static void main(String[] args) {
        Thread thread = new Thread(Volatile::run);
        thread.start();
        Thread thread1 = new Thread(Volatile::stop);
        thread1.start();
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
