import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

class Person implements Comparable<Person> {
    String name;
    int age;

    public int age() {
        return this.age;
    }

        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }

     @Override
     public int compareTo(Person other) {
         return Integer.compare(this.age, other.age); // ascending order
     }


}


public class ComparableComparator {
    public static void main(String[] args) {
        Person p1 = new Person("Alice", 30);
        Person p2 = new Person("Bob", 25);
        Person p3 = new Person("Charlie", 35);
        List<Person> res = List.of(p1, p2, p3);
         // Using Comparator to compare by age
       List<Person> list =  res.stream().sorted(Comparator.comparing(Person::age).reversed()).collect(Collectors.toList());
        list.forEach(p -> System.out.println(p.name + " " + p.age));
    }
}
