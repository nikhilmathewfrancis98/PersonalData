package StreamApiInterview;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FirstUniqueChrInString {
    public static void main(String[] args) {
        String str = "india";
        System.out.println(findFirstUniqueChar(str)); // Output: 'w'
    }

    private static char findFirstUniqueChar(String str) {
//        return str.chars()
//                .mapToObj(c -> (char) c)
//                .collect(Collectors.groupingBy(
//                        Function.identity(),
//                        LinkedHashMap::new,
//                        Collectors.counting()
//                )).entrySet()
//                .stream()
//                .filter(x -> x.getValue() == 1)
//                .findFirst().get().getKey();
        return str.chars()
                .filter(ch -> str.indexOf(ch) == str.lastIndexOf(ch))
                .mapToObj(ch -> (char) ch)
                .findFirst()
                .orElse('\0');
    }
}

/**
 * str.chars()
 *                 .filter(ch -> str.indexOf(ch) == str.lastIndexOf(ch))
 *                 .mapToObj(ch -> (char) ch)
 *                 .findFirst()
 *                 .orElse('\0');
 */