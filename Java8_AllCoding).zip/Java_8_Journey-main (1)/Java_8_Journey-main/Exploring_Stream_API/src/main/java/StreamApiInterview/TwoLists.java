package StreamApiInterview;

import java.util.Arrays;
import java.util.stream.Collectors;

public class TwoLists {
    public static void main(String[] args) {
        Arrays.stream(findCommonElements(new int[]{1, 2, 3, 4, 5,4,5,6}, new int[]{4, 6, 7, 8})).forEach(System.out::println); // Output: [4, 5]
    }

    private static int[] findCommonElements(int[] ints, int[] ints1) {
        return Arrays.stream(ints)
                .filter(x -> Arrays.stream(ints1).anyMatch(y -> y == x))
                .boxed()
                .mapToInt(Integer::intValue)
                .distinct()
                .toArray();
    }
}
