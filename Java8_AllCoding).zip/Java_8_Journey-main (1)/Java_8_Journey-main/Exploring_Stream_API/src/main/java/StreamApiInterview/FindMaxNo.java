package StreamApiInterview;

import java.util.Arrays;

public class FindMaxNo {
    public static void main(String[] args) {
        System.out.println(findMaxInList(new int[]{5, 2, 8, 4, 9, 2, 9}));
    }

    private static long findMaxInList(int[] ints) {
        return Arrays.stream(ints)
                .min() // max() can give maximum
                .orElseThrow(() -> new IllegalArgumentException("Array is empty"));
    }
}
