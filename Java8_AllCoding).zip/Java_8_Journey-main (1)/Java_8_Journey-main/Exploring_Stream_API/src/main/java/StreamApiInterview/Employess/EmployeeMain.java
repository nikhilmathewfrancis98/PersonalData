package StreamApiInterview.Employess;

import java.lang.reflect.Array;
import java.util.*;

public class EmployeeMain {
    public static void main(String[] args) {
        Employee employee1 = new Employee(1, "John", 30, 5000.0, "IT", "New York");
        Employee employee2 = new Employee(2, "Alice", 25, 6000.0, "HR", "Los Angeles");
        Employee employee3 = new Employee(3, "Bob", 35, 7000.0, "Finance", "Chicago");

        Employee employee4 = new Employee(4, "John1", 31, 60000.0, "IT", "New York");
        Employee employee5 = new Employee(5, "Alice1", 21, 70000.0, "HR", "Los Angeles");
        Employee employee6 = new Employee(6, "Bob1", 36, 50000.0, "Finance", "Chicago");

        List<Employee> emp = new ArrayList<>(Arrays.asList(
                employee1, employee2, employee3, employee4, employee5, employee6
        ));

        // Greater than 50000 emp details
      List<Employee> test1 =  emp.stream()
                .filter(e -> e.getSalary() > 50000)
                .collect(java.util.stream.Collectors.toList());
        test1.forEach(e -> System.out.println(e.getName() + " " + e.getSalary()));

//        Highest salary
        Employee highestSalaryEmployee = emp.stream()
                .max(Comparator.comparingDouble(Employee::getSalary))
                .orElse(null);
        if (highestSalaryEmployee != null) {
            System.out.println("Highest Salary Employee: " + highestSalaryEmployee.getName() + " - " + highestSalaryEmployee.getSalary());
        }

//       Optional<Employee> highestSala = emp.stream()
//                .max((Comparator.comparingDouble(Employee::getSalary))
//                        .thenComparing(Comparator.comparingInt(Employee::getAge)));


    }
}
