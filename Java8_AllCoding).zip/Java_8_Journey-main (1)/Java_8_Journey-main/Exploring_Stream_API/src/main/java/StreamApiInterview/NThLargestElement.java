package StreamApiInterview;

public class NThLargestElement {
    public static void main(String[] args) {
        int[] arr = {3, 1, 4, 4,5,3,5, 2};
        int n = 2;
        System.out.println(findNthLargest(arr, n)); // Output: 4
    }

    private static long findNthLargest(int[] arr, int n) {
//        return java.util.Arrays.stream(arr)
//                .boxed()
//                .sorted(java.util.Collections.reverseOrder())
//                .skip(n- 1)
//                .findFirst()
//                .get();

            return java.util.Arrays.stream(arr)
                    .boxed()
                    .sorted(java.util.Collections.reverseOrder())
                    .distinct()
                    .skip(n- 1)
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("n is larger than the array size"));


    }
}
