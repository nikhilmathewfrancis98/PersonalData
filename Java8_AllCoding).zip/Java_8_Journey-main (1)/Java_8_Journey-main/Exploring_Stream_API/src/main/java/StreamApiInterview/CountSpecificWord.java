package StreamApiInterview;

import java.util.Arrays;

public class CountSpecificWord {
    public static void main(String[] args) {
        String str= "Hello my baby I say hello to u H and are same";
        String start = "h";
        System.out.println(countSpecificWord(str, start)); // Output: 4
    }

    private static long countSpecificWord(String str, String start) {
      return  Arrays.stream(str.split(" "))
                .filter(x -> x.toLowerCase().charAt(0) == start.toLowerCase().charAt(0))
                .count();
    }
}
