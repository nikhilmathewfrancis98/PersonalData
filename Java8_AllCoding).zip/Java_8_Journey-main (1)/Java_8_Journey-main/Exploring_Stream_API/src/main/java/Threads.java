import java.util.HashMap;

class SalaryAdder implements Runnable {
    private Employe emp;

    public SalaryAdder(Employe emp) {
        this.emp = emp;
    }

    public void run() {
        emp.addSalary(50000);
    }
}

class SalaryReader implements Runnable {
    private Employe emp;

    public SalaryReader(Employe emp) {
        this.emp = emp;
    }

    public void run() {
        emp.getSalary();
    }
}

class Employe {
    private int salary = 0;
    private boolean isSalaryReady = false;
    private static int counter = 0;

    // add salary (Producer)
    public synchronized void addSalary(int amount) {
        System.out.println(Thread.currentThread().getName() + " adding salary...");

        salary += amount;
        isSalaryReady = true;


        System.out.println("Salary added: " + salary);
        counter += 1;
        if (counter == 3){
            notify();
        }
    }

    // read salary (Consumer)
    public synchronized void getSalary() {
        if (!isSalaryReady) {
            try {
                System.out.println(Thread.currentThread().getName() + " waiting for salary...");
                wait(); // releases lock 🔥
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println(Thread.currentThread().getName() + " got salary: " + salary);
    }

//    public void addCounter(int i) {
//        counter = i;
//    }
}


public class Threads {

    public static void main(String[] args) {

        Employe emp = new Employe();

        Thread t1 = new Thread(new SalaryReader(emp), "ReaderThread");
        Thread t2 = new Thread(new SalaryAdder(emp), "AdderThread");
        Thread t3 = new Thread(new SalaryAdder(emp), "AdderThread");
        Thread t4 = new Thread(new SalaryAdder(emp), "AdderThread");


        t1.start();
        t2.start();
        t3.start();
        t4.start();

        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Main thread finished");

        HashMap<Integer,String> hash= new HashMap<>();
        hash.put(1,"one");
        hash.put(2,"two");
        hash.put(3,"three");
        System.out.println(hash);
    }

}
