import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

class Employee {
    private int id;
    private String name;
    private int age;
    private double salary;
    private String department;
    private String location;

    public Employee(int id, String name, int age, double salary, String department, String location) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.department = department;
        this.location = location;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}

public class ComparableComparator2 {
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        String[] departments = {"HR", "IT", "Finance", "Marketing", "Sales"};
        String[] names = {"Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Hannah", "Ivy", "Jack", "Karen", "Leo", "Mona", "Nina", "Oscar", "Paul", "Quinn", "Rita", "Steve", "Tina"};
        String[] locations = {"Mumbai","Alappuzha","Kochi","Delhi","Bangalore"};
        for (int i = 1; i <= 20; i++) {
            employees.add(new Employee(
                    i, // ID
                    names[ThreadLocalRandom.current().nextInt(names.length)], // Random name
                    ThreadLocalRandom.current().nextInt(23, 60), // Random age between 23 and 60
                    ThreadLocalRandom.current().nextDouble(30000, 120000), // Random salary between 30,000 and 120,000
                    departments[ThreadLocalRandom.current().nextInt(departments.length)], // Random department
                    locations[ThreadLocalRandom.current().nextInt(locations.length)] // Random location
            ));
        }

       Map<String, List<String>> res=  employees.stream()
                .collect(Collectors.groupingBy(
                        Employee::getLocation,
                        Collectors.mapping(Employee::getName, Collectors.toList())
                ));

        System.out.println(res);
    }
}
