import java.io.File;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class PredicateExplore {
    public static void main(String[] args) {
        Map<Boolean, List<Integer>> parts =
                Stream.of(1,2,3,4,5,6)
                        .collect(Collectors.partitioningBy(n -> n % 2 == 0));
//        System.out.println(parts);
//        System.out.println(parts.get(true));  // evens
//        System.out.println(parts.get(false)); // odds

        Map<Boolean, Set<String>> uppercasedDistinctByParity =
                IntStream.rangeClosed(1, 6).boxed()
                        .collect(Collectors.partitioningBy(
                                n -> n % 2 == 0,
                                Collectors.mapping(
                                        n -> ("N" + n).toUpperCase(),
                                        Collectors.toSet()
                                )
                        ));
        System.out.println(uppercasedDistinctByParity);

        Map<Boolean, Integer> maxByParityOrDefault =
                Stream.of(1,3,5,7)
                        .collect(Collectors.partitioningBy(
                                n -> n % 2 == 0,
                                Collectors.collectingAndThen(
                                        Collectors.maxBy(Comparator.naturalOrder()),
                                        (Optional<Integer> opt) -> opt.orElse(-1)
//                                        opt -> opt.orElse(-1)
                                )
                        ));
//        System.out.println(maxByParityOrDefault);

//        ======================================================================

        Predicate<String> nonEmpty = s -> !s.isEmpty();
        Predicate<String> startsWithA = s -> s.startsWith("A");
        Predicate<String> complexPredicate = nonEmpty.and(startsWithA.negate());
        LinkedList list=new LinkedList(Arrays.asList("", "A", "AB", "B", "BA"));
        Iterator iterator=list.listIterator();
            while (iterator.hasNext()){
                String s= (String) iterator.next();
                System.out.println(s);
            }
//        System.out.println("Linked List is: "+list);
//        Stream.of("", "A", "AB", "B", "BA")
//                .filter(complexPredicate)
//                .forEach(System.out::println);

//        Predicate<File> isDirectory = File::isDirectory;
//
//        List<File> dirs =
//                Arrays.stream(new File(".").listFiles())
//                        .filter(isDirectory)
//                        .toList();
//        System.out.println("Dirs==========>\n"+dirs);

    }
}
