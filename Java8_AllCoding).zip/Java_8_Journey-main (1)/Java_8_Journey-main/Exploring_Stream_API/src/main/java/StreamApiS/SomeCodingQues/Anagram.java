package StreamApiS.SomeCodingQues;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public class Anagram {
    public static void main(String[] args) {
        System.out.println(isAnagram("rat", "car")); // false
        System.out.println(isAnagram("anagram", "nagaram")); // true
        System.out.println(isAnagram("listen", "silent")); // true
    }


    private static boolean isAnagram(String s, String t) {
////        return Arrays.equals(s.chars().sorted().toArray(), t.chars().sorted().toArray());
        if (s.length() != t.length()) {
            return false;
        }
      Map<Character, Long> res = s.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(c -> c, Collectors.counting()));
      Map<Character, Long> res2 = t.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(c -> c, Collectors.counting()));
     for (Map.Entry<Character, Long> entry : res.entrySet()) {
         if (!res2.containsKey(entry.getKey()) || !res2.get(entry.getKey()).equals(entry.getValue())) {
             return false;
         }
     }

        return true;
    }
}
