package StreamApiS.SomeCodingQues;

import javax.xml.transform.stax.StAXResult;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class EqualsubsetSum {
    public static void main(String[] args) {
//        int[] arr = {100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,99,97};
        int[] arr = {1,1,1,1,1,1};
         System.out.println(canPartition(arr)); // Output: true
    }

    private static boolean canPartition(int[] arr) {
        int sum = Arrays.stream(arr).sum();
        if(sum % 2 != 0) return false;
        int taget = sum / 2;
        ArrayList<Integer> list = new ArrayList<>();
        list.add(0);
        int TRAct= taget;
        for (int num : arr) {
            int size = list.size();
            taget = TRAct - num;
            for (int i = 0; i < size; i++) {
                int newSum = list.get(i) + num;
//                if (newSum == taget) {
//                    return true;
//                }
                    list.add(newSum);
            }
            if(list.contains(taget)) return true;
        }
            return false;

//        int sum = Arrays.stream(arr).sum();
//        if(sum % 2 != 0) return false;
//        int target = sum / 2;
//
//        Set<Integer> sums = new HashSet<>();
//        sums.add(0);
//        for (int x : arr) {
//            Set<Integer> toAdd = new HashSet<>();
//            for (int s : sums) {
//                toAdd.add(s + x);
//            }
//            sums.addAll(toAdd);
//            if(sums.contains(target)) return true;
//        }
//
//        return false;
    }
}
