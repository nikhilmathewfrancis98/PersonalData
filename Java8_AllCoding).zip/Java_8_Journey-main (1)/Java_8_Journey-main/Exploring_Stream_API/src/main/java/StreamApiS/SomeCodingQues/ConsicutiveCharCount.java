package StreamApiS.SomeCodingQues;

public class ConsicutiveCharCount {
    public static void main(String[] args) {
        System.out.println(countConsicutiveChars("aaabbcaaa")); // Output: a3b2c1a3
    }

    private static String countConsicutiveChars(String str) {
        StringBuilder sb = new StringBuilder();
        int count = 1;
        for (int i=1;i < str.length();i++){
                if (str.charAt(i) != str.charAt(i - 1)){
                    sb.append(str.charAt(i - 1)).append(count);
                    count = 1;
                }else{
                    count++;
                }
                if (i == str.length() - 1){
                    sb.append(str.charAt(i)).append(count);
                }
        }
           return sb.toString();
    }

}