package StreamApiS.SomeCodingQues;

public class AddBinary {
    public static void main(String[] args) {
        System.out.println(addBinary("011", "1011")); // Output: 10101
    }

//    private static String addBinary(String number, String number1) {
//        StringBuilder sb = new StringBuilder();
//        int carry = 0;
//        int i = number.length() - 1;
//        int j = number1.length() - 1;
//        while(i >= 0 || j >= 0 || carry == 1){
//            int sum = carry;
//            if (i >= 0){
//                sum += number.charAt(i) - '0';
//                i--;
//            }
//            if (j >= 0){
//                sum += number1.charAt(j) - '0';
//                j--;
//            }
//            sb.append(sum % 2);
//            carry = sum / 2;
//        }
//        return sb.reverse().toString();
//    }

//    private static String addBinary(String a, String b) {
//        StringBuilder sb = new StringBuilder();
//        int carry = 0;
//        int i = a.length() - 1;
//        int j = b.length() - 1;
//
//        while (i >= 0 || j >= 0 || carry == 1) {
//            int sum = carry;
//
//            if (i >= 0) sum += a.charAt(i--) - '0';
//            if (j >= 0) sum += b.charAt(j--) - '0';
//
//            sb.append(sum % 2);
//            carry = sum / 2;
//        }
//        return sb.reverse().toString();
//    }

//    private static String addBinary(String n1, String n2){
//        int d1 = 0;
//        for(int i = n1.length() - 1; i >= 0; i-- ){
//            d1 += Math.pow(2, n1.length() - 1 - i) * (n1.charAt(i) - '0');
//        }
//        for(int i = n2.length() - 1; i >= 0; i-- ){
//            d1 += Math.pow(2, n2.length() - 1 - i) * (n2.charAt(i) - '0');
//        }
//        StringBuilder sb = new StringBuilder();
//        while(d1 > 0){
//            int rem = d1 % 2;
//            sb.append(rem);
//            System.out.println(rem);
//            d1 = d1 / 2;
//        }
//        return  sb.reverse().toString();
//    }

//    private static String addBinary(String n1, String n2){
//        int d1 = 0;
//        for(int i = n1.length() - 1; i >= 0; i-- ){
//            int bit = n1.charAt(i) - '0';
//            d1 = (d1 << 1) + bit;
//            System.out.println(d1);
//        }
//
//        return  "sb.reverse().toString()";
//    }

    private static String addBinary(String n1, String n2){
        int d1 = 0;
        for(int i = n1.length() - 1; i >= 0; i-- ){
            int sum = d1;
//            d1 += Math.pow(2, n1.length() - 1 - i) * (n1.charAt(i) - '0');
            sum += n1.charAt(i);
            d1 = sum / 2;
        }
        System.out.println(d1);
        return  "";
    }
}
