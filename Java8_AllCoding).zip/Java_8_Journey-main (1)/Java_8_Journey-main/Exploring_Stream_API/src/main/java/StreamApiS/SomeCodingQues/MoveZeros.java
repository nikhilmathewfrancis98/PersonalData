package StreamApiS.SomeCodingQues;

import java.util.Arrays;

/**
 *  This problem is to move all the zeros in an array to the end while maintaining
 *  the relative order of the non-zero elements. The algorithm uses a two-pointer
 *  approach where one pointer (nonZeroIndex) keeps track of the position of the
 *  last non-zero element, and the other pointer (i) iterates through the array.
 *  Whenever a non-zero element is encountered, it is swapped with the element at nonZeroIndex,
 *  and nonZeroIndex is incremented. This way, all non-zero elements are moved to the
 *  front of the array, and all zeros are moved to the end.
 */
public class MoveZeros {
    public static void main(String[] args) {
        int[] nums = {0, 1, 0, 3, 12};
        moveZeroes(nums);
    }

    private static void moveZeroes(int[] nums) {

        int nonZeroIndex = 0;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] != 0) {
                int temp = nums[nonZeroIndex];
                nums[nonZeroIndex] = nums[i];
                nums[i] = temp;
                nonZeroIndex++;
            }
        }
        System.out.println(Arrays.toString(nums));
    }

}

