package StreamApiS.SomeCodingQues;

import java.util.HashMap;
import java.util.Map;

public class BinaryMatrix {
    public static void main(String[] args) {
        System.out.println(numSubmat(new int[][]{{1,0,0},{0,0,1},{1,0,0}})); // Output: 1
    }

    private static int numSubmat(int[][] mat) {
        int val;
        Map<Integer, Integer> matTrack = new HashMap<>();
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                if (mat[i][j] == 1) {
//                    matTrack.getOrDefault(j,0) + 1
                    if (matTrack.containsKey(i)){
                        val = matTrack.get(i);
                        if (matTrack.containsValue(val)) {
                            int finalVal = val;
                          long count =  matTrack.values().stream().filter(v -> v == finalVal).count();
                            if(count >1){
                                matTrack.entrySet().removeIf(entry -> entry.getValue() == finalVal);
                            }
                        }
                        matTrack.remove(i);
                        } else{
                        matTrack.put(i,j);
                    }


                }
            }
        }
        System.out.println(matTrack.toString());
        return matTrack.size();
    }
}
