package StreamApiS.SomeCodingQues;

public class MaxPairSumInArray {
    public static void main(String[] args) {
//                [1,2,3,4] ==> -1
//                [2536,1613,3366,162] ==> 5902
//                [51,71,17,24,42] ==> 88
//                [51,71,17,24,42] => 88
//                [1,2,3,4] => -1
//                [52,32,24,6,3,89,100,3,5,3] => 57
//                [31,25,72,79,74] => 146
//                [84,91,18,59,27,9,81,33,17,58] => 165
//                [87,6,17,32,14,42,46,65,43,9] => 111

//                [68,8,100,84,80,14,88] ==> 172

        System.out.println(maxPairSumInArray(new int[]{68,8,100,84,80,14,88}));
    }

    public static long maxPairSumInArray(int[] nums){
        int maxCount = 0;
        int max1 = 0;
        for (int i = 0; i < nums.length - 1; i++){
            max1 = maxNumber(nums[i]);
            for (int j = i+1; j < nums.length; j++){
                if(max1 == maxNumber(nums[j])) {
                    maxCount = Math.max(maxCount, nums[i] + nums[j]);
                }
            }
        }
        return maxCount == 0 ? -1 : maxCount;
    }

    public static int maxNumber(int no){

        int max = Integer.MIN_VALUE;
        while(no != 0){
            max = Math.max(max, no % 10);
            no /= 10;
        }
        return max;
    }
}
