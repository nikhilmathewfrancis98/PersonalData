package StreamApiS.SomeCodingQues;

public class MaxConsecutiveOnes {
    public static void main(String[] args) {
        System.out.println(maxConsecutiveOnes(new int[]{1, 1, 0, 1, 1, 1})); // Output: 3
    }

    private static int maxConsecutiveOnesOptimized(int[] ints) {
        int maxCount = 0;
        int sum = 0;
        for (int i : ints) {
            if (i == 1) {
                sum++;
            } else {
                maxCount = Math.max(maxCount, sum);
                sum = 0;
            }
        }
        return Math.max(maxCount, sum);
    }
    private static int maxConsecutiveOnes(int[] nums) {
        int maxCount = 0;
        int sum = 0;
        for (int i = 0,j = i;j < nums.length;){
            if(nums[i] == 1 && nums[j] == 1 && nums[i] == nums[j]){
                sum++;
                if(sum > maxCount){
                    maxCount = sum;
                }
                j++;
            }else{
                sum = 0;
                i = j+1;
                j++;
            }

        }

        return maxCount;
    }

}