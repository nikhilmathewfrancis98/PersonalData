package StreamApiS;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

class Employee implements Comparable<Employee> {
    private String name;
    private int age;
    private int id;

    public Employee(String name, int age, int id) {
        this.name = name;
        this.age = age;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    @Override
    public int compareTo(Employee o) {
//        return this.age > o.age ? 1 : (this.age < o.age ? -1 : 0); // ascending order by age
//        return this.age < o.age ? 1 : (this.age > o.age ? -1 : 0);  // descending order by age
//        return this.age > o.age ? -1 : (this.age < o.age ? 1 : 0); // descending
        return this.age > o.age ? 1 : (this.age < o.age ? -1 : 0); // ascending
    }
}
public class ComparableComparatorTesting {
    public static void main(String[] args) {
        List<Employee> list = new ArrayList<>(
                    List.of(new Employee("Alice", 30, 6),
                            new Employee("Bob", 25, 4),
                            new Employee("Charlie", 35, 5),

        new Employee("Bahnu", 34, 2),
                            new Employee("Sonu", 41, 8),
                            new Employee("Meenu", 20, 9),
                            new Employee("Pushpu", 50, 7),

                new Employee("Kamal", 27, 1),
                new Employee("Ummar", 66, 3)
                    ));
        System.out.println("Before");
        list.forEach(e -> System.out.println(e.getName() + " " + e.getAge() + " " + e.getId()));
//        Collections.sort(list, Comparator.comparing(Employee::getAge)); // we used comparator outside class
        Collections.sort(list,
                (a,b) -> {
                if (a.getAge() > b.getAge()){
                    return -1;
                } else if (a.getAge() < b.getAge()) {
                    return 1;
                } else {
                    return 0;
                }
                });
//        Collections.sort(list);
        System.out.println("After");
        list.forEach(e -> System.out.println(e.getName() + " " + e.getAge() + " " + e.getId()));
    }
}
