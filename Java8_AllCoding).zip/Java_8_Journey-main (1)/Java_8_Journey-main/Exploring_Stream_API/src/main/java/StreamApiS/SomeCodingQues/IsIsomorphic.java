package StreamApiS.SomeCodingQues;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class IsIsomorphic {
    public static void main(String[] args) {
//        System.out.println(isIsomorphic("egg", "add")); // true
        System.out.println(isIsomorphic("foo","bar"));
//        System.out.println(isIsomorphic("BADC", "BABA")); // false
//        System.out.println(isIsomorphic("paper", "title")); // true
    }

    private static boolean isIsomorphic(String s, String t) {
//        Map<Character, Character> map = new HashMap<>();
//        int i=0;
//        while (i < s.length()) {
//            if (!map.containsKey(s.charAt(i)) && !map.containsValue(t.charAt(i))) {
//               map.put(s.charAt(i), t.charAt(i));
//               map.put(t.charAt(i), s.charAt(i));
//            }else{
//                int finalI = i;
//                map.computeIfAbsent(t.charAt(i), k -> s.charAt(finalI));
//                map.computeIfAbsent(s.charAt(i), k -> t.charAt(finalI));
//                if (!map.get(s.charAt(i)).equals(t.charAt(i))  || !map.get(t.charAt(i)).equals(s.charAt(i))) {
//                    return false;
//                }
//            }
//            i++;
//        }
//        return true;
        Map<Character, Character> map = new HashMap<>();
        Set<Character> used = new HashSet<>();

        for (int i = 0; i < s.length(); i++) {
            char sc = s.charAt(i);
            char tc = t.charAt(i);

            if (!map.containsKey(sc)) {
                if (used.contains(tc)) return false;

                map.put(sc, tc);
                used.add(tc);
            } else if (map.get(sc) != tc) {
                return false;
            }
        }

        return true;
    }
}
