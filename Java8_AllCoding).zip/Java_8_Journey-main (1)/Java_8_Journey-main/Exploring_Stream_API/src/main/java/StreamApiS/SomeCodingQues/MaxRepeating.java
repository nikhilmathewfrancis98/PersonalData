package StreamApiS.SomeCodingQues;

import java.util.ArrayList;

public class MaxRepeating {
    public static void main(String[] args) {
       getMaxRepeating("aaabaaaabaaabaaaabaaaabaaaabaaaaba", "aaaba");
    }

    private static void getMaxRepeating(String sequence, String word) {
//       ArrayList<String> list = new ArrayList<>();
//        int wordLength = word.length(); // Length of each split
//
//        for (int i = 0; i < sequence.length(); i++) {
//            list.add(sequence.substring(i, Math.min(i + wordLength, sequence.length())));
//        }
//        list.forEach(System.out::println);
//      int res= (int) list.stream()
//                .filter(s -> s.equals(word))
//                .count();
//        System.out.println(res);

        // Correct ans

        int count = 0;
        StringBuilder sb = new StringBuilder(word);
        while (sequence.contains(sb.toString())) {
            count++;
            sb.append(word);
        }
        System.out.println(count);
    }
}
