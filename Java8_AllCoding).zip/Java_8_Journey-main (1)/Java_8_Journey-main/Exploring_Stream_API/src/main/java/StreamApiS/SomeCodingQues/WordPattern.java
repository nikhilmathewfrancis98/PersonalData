package StreamApiS.SomeCodingQues;

import java.util.ArrayList;
import java.util.Map;

public class WordPattern {
    public static void main(String[] args) {
        System.out.println(wordPattern("abbac", "dog cat cat dog")); // true
    }

    private static boolean wordPattern(String abba, String dogCatCatDog) {
        String[] pattern = abba.split("");
        String[] words = dogCatCatDog.split(" ");
        Map<String, String> map = new java.util.HashMap<>();
        for (int i=0; i < pattern.length ; i++){
            if (map.containsKey(pattern[i])) {
                if (!map.get(pattern[i]).equals(words[i])) {
                    return false;
                }
            } else {
                if (map.containsValue(words[i])) {
                    return false;
                }
                map.put(pattern[i], words[i]);
            }
        }

        return true;
    }
}
