package StreamApiS.SomeCodingQues;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OccuranceFrequencySort {
    public static void main(String[] args) {
        String input = "aaabbccd";
        String output = frequencySort(input);
        System.out.println(output); // Output: "dccbbaa" or any other valid output with the same frequency order
    }

    private static String frequencySort(String input) {
       return input.chars()
               .mapToObj(c -> (char) c)
               .collect(Collectors.groupingBy(c -> c, LinkedHashMap::new, Collectors.counting()))
               .entrySet()
               .stream()
               .peek(entry -> System.out.println("Character: " + entry.getKey() + ", Frequency: " + entry.getValue()))
               .sorted(Map.Entry.comparingByValue())
               .map(entry -> String.valueOf(entry.getKey()).concat(String.valueOf(entry.getValue())))
               .collect(Collectors.joining());
    }
}
