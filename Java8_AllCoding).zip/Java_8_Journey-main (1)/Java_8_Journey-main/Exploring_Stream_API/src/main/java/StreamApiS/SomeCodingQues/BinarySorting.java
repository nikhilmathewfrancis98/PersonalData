package StreamApiS.SomeCodingQues;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Collector;

public class BinarySorting {
    public static void main(String[] args) {
        int[] arr = {1, 0, 1, 1, 0, 0, 1, 0, 1};
//        Arrays.stream(arr)
//                .boxed()
//                .sorted(Comparator.comparingInt(Integer::intValue).reversed())
//                .forEach(System.out::println);

//        Without streams with and without new list we can do
//        ArrayList<Integer> list = new ArrayList<>();
//        int countZeros = 0;
//        for (int num : arr){
//            if (num == 0){
//                countZeros ++;
//            }
//        }
//
//        for (int i = 0; i < countZeros; i++){
//            list.add(0);
//        }
//
//        for (int i = countZeros; i < arr.length; i++){
//            list.add(1);
//        }
//
//        System.out.println(list);


    }
}
