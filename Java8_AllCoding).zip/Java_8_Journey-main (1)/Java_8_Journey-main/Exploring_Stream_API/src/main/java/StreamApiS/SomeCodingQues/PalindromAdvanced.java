package StreamApiS.SomeCodingQues;

public class PalindromAdvanced {
    public static void main(String[] args) {
        System.out.println(isPalindrome("c1 O$d@eeD o1c"));
    }

    public static boolean isPalindrome(String s) {
      StringBuilder res =  s.chars().collect(StringBuilder::new, (sb, c) -> {
            if (Character.isLetterOrDigit(c)) {
                sb.append(Character.toLowerCase((char)c));
            }
        }, StringBuilder::append);
        System.out.println(res.toString());
        return  res.toString().equals(res.reverse().toString());
        }
}
