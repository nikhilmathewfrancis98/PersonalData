package StreamApiS.SomeCodingQues;

import java.util.HashMap;
import java.util.Map;

public class BinaryRepresentationToOne {
    public static void main(String[] args) {
//        1111011110000011100000110001011011110010111001010111110001
        System.out.println(numStepsOptimized("1111011110000011100000110001011011110010111001010111110001")); // Output: 1
    }

//    private static int numSteps(String s) {
//        int num = 0,count = 0;
//        for (int i=s.length() - 1;i >= 0;i--){
//            if (s.charAt(i) == '1'){
//                num+= (int) Math.pow(2,s.length() - 1 - i);
//            }
//        }
//        if (num == 0) return 0;
//        while (num != 1){
//            if (num % 2 == 0){
//                num = num / 2;
//            }else{
//                num = num + 1;
//            }
//            count++;
//        }
//
//        return count;
//    }

//    private static int numSteps(String s) {
//        int num = 0,count = 0;
//        for (int i=s.length() - 1;i >= 0;i--){
//            if (s.charAt(i) == '1'){
//                num+= (int) Math.pow(2,s.length() - 1 - i);
//            }
//        }
//        if (num == 0) return 0;
//        while (num != 1){
//            if (num % 2 == 0){
//                num = num / 2;
//            }else{
//                num = num + 1;
//            }
//            count++;
//        }
//
//        return count;
//    }

    private static int numSteps(String s) {
        int num ,count = 0;
        for (int i=s.length() - 1;i >= 0;i--){
            if (s.charAt(i) == '1'){
                num = (int) Math.pow(2,s.length() - 1 - i);
                while (num != 1){
                    if (num % 2 == 0){
                        num = num / 2;

                    }else{
                        num = num + 1;

                    }
                    count++;
                }
            }
        }

        return count;
    }

    private static int numStepsOptimized(String s) {
            int count = 0;
            StringBuilder s1= new StringBuilder(s);
            while (!s1.toString().equals("1")){
                if (s1.charAt(s1.length() - 1) == '0'){
                    s1.deleteCharAt(s1.length() - 1);
                }else{
                    int i = s1.length() - 1;
                    while (i >= 0 && s1.charAt(i) == '1'){
                        s1.setCharAt(i,'0');
                        i--;
                    }
                    if (i >= 0){
                        s1.setCharAt(i,'1');
                    }else{
                        s1.insert(0,'1');
                    }
                }
                count++;
            }
        return count;
    }
}
