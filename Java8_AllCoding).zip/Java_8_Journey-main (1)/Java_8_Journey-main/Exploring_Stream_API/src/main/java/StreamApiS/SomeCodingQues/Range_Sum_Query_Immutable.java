package StreamApiS.SomeCodingQues;

public class Range_Sum_Query_Immutable {

    // Approach 1 Brute force
    static int[] numsArray;
    static int[] prefixArray;
//    static{
//       numsArray = new int[]{-2,0,3,-5,2,-1};
//    }
    static {
        numsArray = new int[]{-2,0,3,-5,2,-1};
        prefixArray = new int[numsArray.length];
        for (int i = 0; i < numsArray.length; i++) {
            if (i == 0) {
                prefixArray[i] = numsArray[i];
            } else {
                prefixArray[i] = prefixArray[i - 1] + numsArray[i];
            }
        }
    }
    public static void main(String[] args) {
//        System.out.println( sumRange(0,2)); // 1
//        System.out.println(sumRange(2,5)); // -1
//        System.out.println(sumRange(0, 5)); // -3
        System.out.println( sumRange2(0,2)); // 1
        System.out.println(sumRange2(2,5)); // -1
        System.out.println(sumRange2(0, 5)); // -3
    }

    private static int sumRange(int left, int right) {
        int sum = 0;
        for(int i=left;i<=right;i++){
            sum+=numsArray[i];
        }
        return sum;
    }

    private static int sumRange2(int left, int right){
        return prefixArray[right] - (left > 0 ? prefixArray[left - 1] : 0);
    }
}
