package StreamApiS.SomeCodingQues;

public class PrefixSum {
    public static void main(String[] args) {
        int[] nums = {-2,0,3,-5,2,-1}; // -2,-2,1,-4,-2,-3
       int[] prefixRes = findPrefixSum(nums);
        System.out.println("\nPrefix Sum Result: " + java.util.Arrays.toString(prefixRes));
    }

    private static int[] findPrefixSum(int[] nums) {
       int[] prefixSum = new int[nums.length];
       for (int i = 0; i < nums.length; i++) {
           if (i == 0) {
               prefixSum[i] = nums[i];
           } else {
               prefixSum[i] = prefixSum[i - 1] + nums[i];
           }
       }
        return prefixSum;
    }
}
