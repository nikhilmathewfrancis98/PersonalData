package StreamApiS.SomeCodingQues;

public class MaxConsecutiveOnesIII {
    public static void main(String[] args) {
        System.out.println(maxConsecutiveOnesIII(new int[]{1,1,1,0,0,0,1,1,1,1,0}, 2)); // Output: 6
    }

    private static int maxConsecutiveOnesIII(int[] nums, int k) {
        int maxCount = Integer.MIN_VALUE;
        for (int i=0,j=0;j< nums.length;j++){
            if(nums[j] == 0){
                k--;
            }
            while(k < 0) {
                if (nums[i] == 0) {
                    k++;
                }
                i++;
            }

            maxCount = Math.max(maxCount, j - i + 1);
        }

        return maxCount;
    }
}
