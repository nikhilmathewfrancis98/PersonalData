//package StreamApiS;
//
//import java.util.List;
//
//public class FlatMap {
//    public static void main(String[] args) {
//        List<List<Integer>> lists = List.of(
//                List.of(1, 2),
//                List.of(3, 4)
//        );
//
//        lists.stream()
//                .flatMap()
//
//    }
//}
