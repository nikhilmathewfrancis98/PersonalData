package StreamApiS.SomeCodingQues;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class LongestNiceSubstring {
    public static boolean hasAllCasePairs(String text) {
        Set<Character> charSet = new HashSet<>();
        for (char c : text.toCharArray()) {
            charSet.add(c);
        }

        for (char c : charSet) {
            if (Character.isLetter(c)) {
                char upper = Character.toUpperCase(c);
                char lower = Character.toLowerCase(c);

                // If either version is missing from the set, return false
                if (!charSet.contains(upper) || !charSet.contains(lower)) {
                    return false;
                }
            }
        }

        return true;
    }
    public static String findSubstrings(String s) {
        String res = "";
        for (int i = 0; i < s.length(); i++) {
            for (int j = i; j < s.length(); j++) {
                if (hasAllCasePairs(s.substring(i, j + 1)) && s.substring(i, j + 1).length() > res.length()) {
                    res = s.substring(i, j + 1);
                }
            }
        }
        return res;
    }

    public static String longestNiceSubstring(String s) {
        String longestSubString= "";
        if (s.length() < 2) {
            return longestSubString;
        }
        for (char x: s.toCharArray()) {
            if (s.indexOf(Character.toLowerCase(x)) != -1 && s.indexOf(Character.toUpperCase(x)) != -1) {
                continue;
            }
            String left = longestNiceSubstring(s.substring(0, s.indexOf(x)));
            String right = longestNiceSubstring(s.substring(s.indexOf(x) + 1));
            longestSubString = left.length() >= right.length() ? left : right;
        }
        return longestSubString.isEmpty() ? s : longestSubString;
    }
    public static void main(String[] args) {
//        String s = "YazaAay";
        String s = "Bb";
//        String s = "abABB";
        String LongestRes = longestNiceSubstring(s);
            System.out.print(LongestRes + " ");

    }
}
