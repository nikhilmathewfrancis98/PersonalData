package StreamApiS.SomeCodingQues;

import java.util.*;
import java.util.stream.Collectors;

public class SecondMostRepeatingNumber {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 2, 5, 1}; // 1 and 2 are repeating numbers, 5 o/p
        int[] arr2 = {1, 2, 3, 4, 5, 6}; // No repeating numbers
        int[] arr3 = {1,2,2,2,3,3,3,4}; // 2 and 3 are repeating numbers, 4 o/p
        System.out.println(findSecondRepeatingNumber(arr3)); // Output: 2
    }

    private static int findSecondRepeatingNumber(int[] arr) {


        int result = Arrays.stream(arr)
                .boxed()
                .collect(Collectors.groupingBy(i -> i, Collectors.counting()))
                .entrySet()
                .stream()
                // group by frequency
                .collect(Collectors.groupingBy(
                        Map.Entry::getValue,
                        Collectors.mapping(Map.Entry::getKey, Collectors.toList())
                ))
                .entrySet()
                .stream()
                .sorted(Map.Entry.<Long, List<Integer>>comparingByKey().reversed())
                .skip(1) // 2nd highest frequency
                .map(e -> Collections.max(e.getValue())) // pick max key
                .findFirst()
                .orElse(-1);

        System.out.println(result);

        return 0;
    }
}
