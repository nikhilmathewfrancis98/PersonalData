package StreamApiS.SomeCodingQues;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupAnagrams {
    public static void main(String[] args) {
        someMethod(new String[]{"eat", "tea", "tan", "ate", "nat", "bat"});
    }

    private static void someMethod(String[] strings) {
        Map<String,String>  res = new HashMap<>();
//        for(String x : strings){
//            if (res.containsKey(x.chars().sorted().collect(StringBuilder:: new, StringBuilder::appendCodePoint, StringBuilder::append).toString())){
//                res.put(x.chars().sorted().collect(StringBuilder:: new, StringBuilder::appendCodePoint, StringBuilder::append).toString(), res.get(x.chars().sorted().collect(StringBuilder:: new, StringBuilder::appendCodePoint, StringBuilder::append).toString()) + "," + x);
//            }else {
//                res.put(x.chars().sorted().collect(StringBuilder:: new, StringBuilder::appendCodePoint, StringBuilder::append).toString(), x);
//            }
//
//        }
//        Arrays.stream(strings).sequential().forEach(x->{
//            String sorted = x.chars().sorted().collect(StringBuilder::new,StringBuilder::appendCodePoint,StringBuilder::append).toString();
//            String val = res.getOrDefault(sorted, "") + (res.containsKey(sorted) ? "," : "") + x;
//            res.put(sorted, val);
//        });

//            Arrays.stream(strings).sequential().forEach(x->{
//                String sorted = x.chars().sorted().collect(StringBuilder::new,StringBuilder::appendCodePoint,StringBuilder::append).toString();
//                res.merge(sorted, x, (oldVal, newVal) -> oldVal + "," + newVal);
//            });

        Arrays.stream(strings).sequential().collect(Collectors.groupingBy(x -> x.chars().sorted()
                        .collect(StringBuilder::new, StringBuilder::appendCodePoint,
                                StringBuilder::append).toString(),
                        Collectors.joining(",")))
                .forEach((key, value) -> res.put(key, value));
        System.out.println(res);
    }
}
