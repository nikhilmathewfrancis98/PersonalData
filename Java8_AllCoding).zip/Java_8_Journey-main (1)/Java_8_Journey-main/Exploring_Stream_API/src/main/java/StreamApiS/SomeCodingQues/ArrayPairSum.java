package StreamApiS.SomeCodingQues;

import java.util.Arrays;

public class ArrayPairSum {
    public static void main(String[] args) {
        int[] arr = {3,1,2,4};
       int res =  arrayPairSum(arr);
        System.out.println(res);
    }

    private static int arrayPairSum(int[] arr) {
       int[] newSorted = Arrays.stream(arr).sorted().toArray();
       int sum = 0;
        for (int i = 0, j = i+1; i < newSorted.length - 1; i += 2, j= i + 1) {
            sum += Math.min(newSorted[i],newSorted[j]);
        }
        System.out.println("Sorted array: " + Arrays.toString(newSorted));

        return sum;
    }
}
