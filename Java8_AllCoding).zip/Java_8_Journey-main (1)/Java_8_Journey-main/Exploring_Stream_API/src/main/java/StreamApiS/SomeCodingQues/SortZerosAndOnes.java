package StreamApiS.SomeCodingQues;

public class SortZerosAndOnes {
    public static void main(String[] args) {
        int[] arr = {0, 1, 0, 1, 1, 0};
        sortZerosAndOnes(arr);

    }

    private static void sortZerosAndOnes(int[] arr) {
       int i=0;
         for (int j=0;j<arr.length;j++) {
             if (arr[j] == 0) {
                 int temp = arr[i];
                 arr[i] = arr[j];
                 arr[j] = temp;
                 i++;
             }
         }
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
}
