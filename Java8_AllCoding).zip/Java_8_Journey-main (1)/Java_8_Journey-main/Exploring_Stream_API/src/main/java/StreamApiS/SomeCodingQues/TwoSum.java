package StreamApiS.SomeCodingQues;

import java.util.*;

public class TwoSum {
    public static void main(String[] args) {
//        Arrays.stream(twoSumSecondApp(new int[]{2, 3, 5, 1, 4, 10, 5}, 10)).asLongStream().forEach(System.out::println); // Output: [0,1]
        System.out.println(twoSumThirdApp(new int[]{-1, 0, 1, 2, -1, -4}, 0));
    }

    // The below can be applied for sorted array only
    private static int[] twoSumOneApp(int[] nums, int target) {
        int i = 0, j = nums.length - 1;
        while (i < j) {
            if (nums[i] + nums[j] == target) {
                break;
            } else if (nums[i] + nums[j] < target) {
                i++;
            } else {
                j--;
            }
        }

        return new int[]{i, j};
    }

    // The below can be applied for unsorted array as well with 2 for
    // loops and checking for each pair of elements if they sum up to target or not.
    // Time complexity will be O(n^2) in that case.
    private static int[] twoSumSecondApp(int[] nums, int target) {
        HashMap<Integer, Integer> set = new HashMap<>();
        ArrayList<Integer> res = new ArrayList<>();
        for (int i = 0; i < nums.length - 2; i++) {
            int complement = target - nums[i];
            for (int j = i + 1; j < nums.length; j++) {
                if (res.size() > 0) break;
                if (nums[i] + nums[j] == target || nums[i] + nums[j] > target) {
                    break;
                }
                if (set.containsKey(complement - nums[j])) {
                    res.addAll(List.of(i, j, set.get(complement - nums[j])));
                    return res.stream().mapToInt(Integer::intValue).toArray();
                }else {
                    set.put(nums[j], j);
                }
            }
        }
        return res.stream().mapToInt(Integer::intValue).toArray();

    }
//    In the below code we take the unique triplets ie indices
    private static List<List<Integer>> twoSumThirdApp(int[] nums, int target) {
        int n = nums.length;
        List<List<Integer>> result = new ArrayList<>();
        HashMap<String,int[]> keyValue = new HashMap<>();
        for (int i = 0; i < n - 2; i++) {
            Map<Integer, Integer> seen = new HashMap<>();
            for (int j = i + 1; j < n; j++) {
                int need = target - nums[i] - nums[j];

                Integer k = seen.get(need);
                if (k != null) {
                    // Generating a key and storing that to Map to
//                    get the unique triplets
                    int a = i, b = j, c = k;
                    int minVal = Math.min(nums[a], Math.min(nums[b], nums[c]));
                    int maxVal = Math.max(nums[a], Math.max(nums[b], nums[c]));
                    int midVal = a + b+ c - minVal - maxVal;
                    String key = minVal + "#" + midVal + "#" + maxVal;
                    // Now prepare the index in asc-desc for determining
                    // the unique triplets
                    int x = i, y = k, z = j;
                    if (x > y) { int t = x; x = y; y = t; }
                    if (y > z) { int t = y; y = z; z = t; }
                    if (x > y) { int t = x; x = y; y = t; }
                    int[] candidate = new int[] { x, y, z };
                    if (!keyValue.containsKey(key) || !Arrays.equals(keyValue.get(key), candidate)) {
                        keyValue.put(key, candidate);
                    }

// result.add(Arrays.stream(new int[] { i,k,j }).boxed().toList());
                }

                seen.putIfAbsent(nums[j], j);
            }
        }

//        Converting to out output

//result.stream().mapToInt(list -> list.stream().mapToInt(Integer::intValue).toArray()).flatMapToInt(Arrays::stream).toArray()
        return result;
    }
}


/**
 import java.util.*;

 public class ThreeSumAllUniqueIndicesNoSort {


  Returns all unique triplets of indices [i, k, j] such that
  nums[i] + nums[k] + nums[j] == target, with uniqueness defined by VALUES
  (like LeetCode 3Sum). For each unique value triplet, one representative
  index triplet is returned. The input array is NOT sorted.

  Example: nums = [-1, 0, 1, 2, -1, -4], target = 0
  Might return something like: [[0, 2, 3], [0, 1, 4]] (indices correspond to
  value triplets [-1, -1, 2] and [-1, 0, 1]).


public static List<List<Integer>> threeSumAllUniqueIndexTriplets(int[] nums, int target) {
    int n = nums.length;

    // Map from canonical value triplet "a#b#c" (a<=b<=c) -> best (lexicographically smallest) index triple [i,k,j]
    Map<String, int[]> bestForValueKey = new HashMap<>();

    for (int i = 0; i < n - 2; i++) {
        // For current i, we solve 2-sum on nums[i+1..n-1]
        Map<Integer, Integer> seen = new HashMap<>(); // value -> earliest index k in (i+1..j-1)

        for (int j = i + 1; j < n; j++) {
            int need = target - nums[i] - nums[j];

            Integer k = seen.get(need);
            if (k != null) {
                // Found nums[i] + nums[k] + nums[j] == target

                // Build canonical VALUE key (a<=b<=c) WITHOUT sorting the array.
                int a = nums[i], b = nums[k], c = nums[j];
                int minv = Math.min(a, Math.min(b, c));
                int maxv = Math.max(a, Math.max(b, c));
                int midv = a + b + c - minv - maxv;
                String key = minv + "#" + midv + "#" + maxv;

                // Prepare INDEX triple in ascending order for determinism
                int x = i, y = k, z = j;
                if (x > y) { int t = x; x = y; y = t; }
                if (y > z) { int t = y; y = z; z = t; }
                if (x > y) { int t = x; x = y; y = t; }
                int[] candidate = new int[] { x, y, z };

                // Keep the lexicographically smallest index triple for this value triplet
                int[] prev = bestForValueKey.get(key);
                if (prev == null || lexLess(candidate, prev)) {
                    bestForValueKey.put(key, candidate);
                }
            }

            // Add AFTER checking, to avoid reusing the same j as both elements in the pair
            seen.putIfAbsent(nums[j], j); // keep earliest index for each value
        }
    }

    // Convert to the requested output format
    List<List<Integer>> result = new ArrayList<>();
    for (int[] idx : bestForValueKey.values()) {
        result.add(Arrays.asList(idx[0], idx[1], idx[2]));
    }

    // Optional: sort results by indices for stable/deterministic output
    result.sort((u, v) -> {
        if (!u.get(0).equals(v.get(0))) return Integer.compare(u.get(0), v.get(0));
        if (!u.get(1).equals(v.get(1))) return Integer.compare(u.get(1), v.get(1));
        return Integer.compare(u.get(2), v.get(2));
    });

    return result;
}

// Helper: lexicographic comparison for int[3]
private static boolean lexLess(int[] a, int[] b) {
    if (a[0] != b[0]) return a[0] < b[0];
    if (a[1] != b[1]) return a[1] < b[1];
    return a[2] < b[2];
}

// Demo
public static void main(String[] args) {
    int[] nums1 = {-1, 0, 1, 2, -1, -4};
    System.out.println(threeSumAllUniqueIndexTriplets(nums1, 0));
    // Example output (indices may vary but value-unique):
    // [[0, 2, 3], [0, 1, 4]] => corresponds to values [-1,-1,2] and [-1,0,1]

    int[] nums2 = {2, 3, 5, 1, 4, 10, 5};
    System.out.println(threeSumAllUniqueIndexTriplets(nums2, 10));
    // Example: could include [0,1,2] -> 2+3+5=10, and [3,4,6] -> 1+4+5=10

    int[] nums3 = {0, 0, 0, 0};
    System.out.println(threeSumAllUniqueIndexTriplets(nums3, 0));
    // Should return one triplet of indices (e.g., [0,1,2]) for the value triplet [0,0,0]
}
}
 **/