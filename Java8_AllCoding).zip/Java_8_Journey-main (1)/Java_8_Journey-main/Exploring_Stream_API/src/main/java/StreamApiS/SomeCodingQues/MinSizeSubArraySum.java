package StreamApiS.SomeCodingQues;

public class MinSizeSubArraySum {
    public static void main(String[] args) {
        /** some inputs
         *
         */
        System.out.println(minSizeSubArraySum(7, new int[]{2,3,1,2,4,3,3,4,7})); // Output: 1
    }

    private static int minSizeSubArraySum(int target, int[] nums) {
        int minSize = Integer.MAX_VALUE;
        int sum = 0;
        for (int j = 0, k = 0; j < nums.length; j++) {
            sum += nums[j];
            while (sum >= target) {
                minSize = Math.min(minSize, j - k + 1);
                sum -= nums[k];
                k++;
            }
        }
        return minSize == Integer.MAX_VALUE ? 0 : minSize;
    }

}
