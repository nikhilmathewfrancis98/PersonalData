package StreamApiS.SomeCodingQues;

public class SecondlargestWithoutStream {
    public static void main(String[] args) {
        int[] arr = {5, 3, 9, 1, 7, 7, 9, 2,8,8};
        int largest = Integer.MIN_VALUE;
        int secondLargest = Integer.MIN_VALUE;
//
        for (int num : arr) {
            if (num > largest) {
                secondLargest = largest;
                largest = num;
            } else if (num > secondLargest && num != largest) {
                secondLargest = num;
            }
        }

//        for(int ar : arr){
//            if(ar > largest){
//                if(largest > secondLargest){
//                    secondLargest = largest;
//                }
//                largest = ar;
//
//            }else if(ar > secondLargest && ar != largest){
//                secondLargest = ar;
//            }
//        }

        System.out.println("Second largest number is: " + secondLargest);
    }
}
