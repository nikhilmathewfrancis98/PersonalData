package StreamApiS.SomeCodingQues;

public class SubArrayProductLessThanK {
    public static void main(String[] args) {
        /**
         * 10,9,10,4,3,8,3,3,6,2,10,10,9,3  ==> 19
         */
        System.out.println(numSubarrayProductLessThanK(new int[]{10,9,10,4,3,8,3,3,6,2,10,10,9,3}, 19)); // Output: 18
    }

    private static int numSubarrayProductLessThanK(int[] nums, int k) {
        int product = 1;
        int count = 0;
        for(int i=0,j=0; i <= j && j < nums.length;j++){
            product *= nums[j];
            while(product >= k && i <= j){
                product = product / nums[i];
                i++;
            }
            count+=(j - i + 1);
        }

        return count;
    }
}


 /** if(k < 1) return 0;
int product = 1;
int count = 0;
        for(int i=0,j=0; i <= j && j < nums.length;j++){
product *= nums[j];
        if (product  < k){
count+=(j - i + 1);
        }
        while(product >= k && i <= j){
product = product / nums[i];
i++;
count+=(j - i + 1);
        }
        }
        return  count; **/