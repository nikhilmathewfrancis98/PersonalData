package StreamApiS.SomeCodingQues;

public class BConsecutive {

    public static void main(String[] args) {
        System.out.println(maxSumOfBConsecutiveElementsOptimized(new int[]{1,2,3,4,5}, 2)); // Output: 9 (4 + 5)
    }

    public static long maxSumOfBConsecutiveElements(int[] nums, int B) {
        if (B == 0 || B > nums.length) return 0;
        long sum = Long.MIN_VALUE;
        long kSum;
        int i=0,j = B - 1;
        while(j <= nums.length - 1 ){
            System.out.println("i: "+i+" j: "+j);
            kSum=0;
            for (int k = i;k <= j; k++){
                kSum+=nums[k];
            }
            if(kSum>sum){
                sum=kSum;
            }
            i++;
            j++;
        }
        return sum;
    }

    public static long maxSumOfBConsecutiveElementsOptimized(int[] nums, int B) {
        if (B == 0 || B > nums.length) return 0;
        int maxSum = 0;
        for(int i = 0; i < B; i++) {
            maxSum += nums[i];
        }
        int i = 1;
        int j = B;
        while(j < nums.length) {
            int currentSum = (maxSum - nums[i-1]) + nums[j];
            maxSum = Math.max(maxSum, currentSum);
            i++;
            j++;
        }

//        while(j < nums.length) {
//            int sum = maxSum + nums[j] - nums[i - 1];
//            if (sum > maxSum) {
//                maxSum = sum;
//            }
//            i++;
//            j++;
//        }

        return maxSum;
    }

}
