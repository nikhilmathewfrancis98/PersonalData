package StreamApiS.SomeCodingQues;

public class convertToTitle {
    public static void main(String[] args) {
        System.out.println(convertToTitle(123));

        int decodeNo = 123;
        StringBuilder sr = new StringBuilder(Integer.toString(decodeNo));

        char c = (char) 1 + 'A' - 1;
        char val = (char) 12 + 'A' - 1;
        System.out.println(val + "    "+ c);
//        System.out.println(convertToTitleBase26ToDecimal("AZ"));
    }

    private static String convertToTitleBase26ToDecimal(String val) {

//        int result = 0;
//        for (int i = 0; i < val.length(); i++) {
//            char c = val.charAt(i);
//            result = result * 26 + (c - 'A' + 1);
//        }
//        return String.valueOf(result);

//        Base26 to Decimal
        int result = 0;
        for (int i = 0; i < val.length(); i++) {
            int c = val.charAt(i) - 'A' + 1;
            result = result * 26 + c;
        }
        return String.valueOf(result);

    }
    private static String convertToTitle(int columnNumber) {
        StringBuilder sr = new StringBuilder();
        while (columnNumber > 0){
            columnNumber--;
            char result = (char) (columnNumber % 26);
                result += 'A';
            sr.append(result);
            columnNumber = columnNumber/26;
        }
        return sr.reverse().toString();
    }

}
