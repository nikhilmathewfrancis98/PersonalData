package Recursion;

public class NoOFStepsToReduceANumberToZero {
    public static void main(String[] args) {
        int num = 8;
        int steps = countStepsToReduceToZeroRecursion(num);
        System.out.println("Number of steps to reduce " + num + " to zero: " + steps);
    }
    // Approach 1 without recursion
    private static int countStepsToReduceToZero(int num) {
        int count = 0;
        int nums = num;
        while(nums > 0){
            if (nums % 2 == 0){
                nums/=2;
                ++count;
            }else{
                nums-=1;
                ++count;
            }

        }
        return count;
    }

//    Approach 2 using recursion
    private static int countStepsToReduceToZeroRecursion(int num) {
//        int count = 0;
        if (num == 0) {
            return 0;
        } else if (num % 2 == 0) {
//           count+= countStepsToReduceToZeroRecursion(num / 2);
//           count++;
            return  1 + countStepsToReduceToZero(num / 2);
        } else {
//           count+= countStepsToReduceToZeroRecursion(num - 1);
//            count++;
            return 1 + countStepsToReduceToZero(num - 1);
        }

//        return count;
    }
}
