package Recursion;

public class CountOperationstoObtainZero {
    public static void main(String[] args) {
        System.out.println(countOperationsRecursion(10, 10)); // Op 3
    }

//    Approach without recursion
    public static int countOperations(int num1, int num2) {
        int count = 0;
        while(num1 > 0 && num2 > 0) {
            if (num1 >= num2) {
                num1 -= num2;
                count++;
            } else {
                num2 -= num1;
                count++;
            }
        }
        return count;
    }

//    Approach using recursion
    public static int countOperationsRecursion(int num1, int num2) {
       if(num1 == 0 || num2 == 0){
            return 0;
       }
       if (num1 >= num2){
           return 1 + countOperationsRecursion(num1 - num2, num2);
       }else {
           return 1 + countOperationsRecursion(num1, num2 - num1);
       }
    }
}
