package BinarySearch;

import java.util.HashMap;
import java.util.Map;

public class FindIndex {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9}; // o/p : 4
        int target = 5;
        int index = findIndex2(arr, target);
        System.out.println("Index of " + target + " is: " + index);
    }
//    Using Binary search
    private static int findIndex(int[] arr, int target) {
        int left=0;
        int right = arr.length;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (target == arr[mid]) return mid;
            else if (target < arr[mid]) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        }
            return -1;
    }

//    using hashmap
    private static int findIndex2(int[] arr, int target){
        Map<Integer,Integer> mapRes = new HashMap<>();
        for (int i =0;i<arr.length;i++){
            mapRes.put(arr[i],i);
        }
        return mapRes.getOrDefault(target,-1);
    }
}
