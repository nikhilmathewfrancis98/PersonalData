package BinarySearch;

public class JumpSearch {
    public static void main(String[] args) {
        int[] nums = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
        int target = 12;
        findNumberByJump(nums, target);
    }

    private static void findNumberByJump(int[] arr, int target) {
        int jump = (int) Math.sqrt(arr.length) - 1;
        int nextJump = jump;
        int prev = 0;
        int indexFound=0;
        while(arr[nextJump] < target){
            prev=nextJump;
            nextJump += jump;
        }
        for (int i = prev; i <= nextJump; i++){
            if (arr[i] == target){
                indexFound = i;
                break;
            }
        }
        System.out.println(indexFound);
    }
}
