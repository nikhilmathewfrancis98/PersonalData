package MonotonicStack;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Stack;

public class LC496_Next_Greater_Element_I {
    public static void main(String[] args) {
//        Arrays.stream(nextGreaterElement(new int[]{1,3,5,2,4}, new int[]{6,5,4,3,2,1,7}))
//                .forEach(System.out::print);
        Arrays.stream(nextGreaterElement(new int[]{4,1,2}, new int[]{1,3,4,2}))
                .forEach(System.out::print);
    }
    public static int[] nextGreaterElement(int[] nums1, int[] nums2) {
//        int[] ans1 = new int[nums2.length];
//        int[] ans2 = new int[nums1.length];
//        Map<Integer, Integer> map = new java.util.HashMap<>();
////        Arrays.fill(ans1, -1);
////        Arrays.fill(ans2, -1);
//        Stack<Integer> stack = new Stack<>();
//        for (int i = 0; i < nums2.length; i++) {
//            while (!stack.isEmpty() && nums2[i] > nums2[stack.peek()]) {
////                ans1[stack.pop()] = nums2[i];
//                map.put(nums2[stack.pop()], nums2[i]);
//            }
//            stack.push(i);
//        }
//        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
//            System.out.println(entry.getKey() + " -> " + entry.getValue());
//        }
////        for (int i = 0 ; i < nums1.length; i++) {
////            ans2[i] = map.get(nums1[i]);
////        }
//        return ans2;

        int[] result = new int[nums1.length];
        java.util.Map<Integer, Integer> map = new java.util.HashMap<>();
        java.util.Stack<Integer> stack = new java.util.Stack<>();

        for (int num : nums2) {
            while (!stack.isEmpty() && stack.peek() < num) {
                map.put(stack.pop(), num);
            }
            stack.push(num);
        }

        for (int i = 0; i < nums1.length; i++) {
            result[i] = map.getOrDefault(nums1[i], -1);
        }

        return result;
    }
}
