package MonotonicStack;

import java.util.Arrays;
import java.util.Stack;

public class NextGreaterElement_NGE {
    public static void main(String[] args) {
        int[] arr = {5,1,4}; // o/p : -1 4 -1
//        int[] arr = {2,1,3,4}; // o/p : 3 3 4 -1
//        int[] arr = {2,1,3}; // o/p : 3 3 -1
//        int[] arr = {5,4,3}; // o/p : -1 -1 -1
        int[] nge = nextGreaterElement(arr);
        for (int num : nge) {
            System.out.print(num + " ");
        }
    }

    private static int[] nextGreaterElement(int[] arr) {
        int[] ans = new int[arr.length];
        Arrays.fill(ans, -1);
        Stack<Integer> stack = new Stack<>();
        for (int i = 0; i < arr.length; i++) {
                while (!stack.isEmpty() && arr[i] > arr[stack.peek()]) {
                    ans[stack.pop()] = arr[i];
                }
                stack.push(i);
        }

        return ans;
    }
}
