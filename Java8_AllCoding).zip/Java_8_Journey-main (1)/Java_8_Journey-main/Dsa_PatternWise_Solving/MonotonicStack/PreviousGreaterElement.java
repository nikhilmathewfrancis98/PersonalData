package MonotonicStack;

public class PreviousGreaterElement {
    public static void main(String[] args) {

    }
}
