package MonotonicStack;

import java.util.Arrays;
import java.util.Stack;

public class NextSmallerElement_NSE {
    public static void main(String[] args) {
        int[] arr = {4,8,5,2}; // o/p : 2,5,2,-1
        int[] result = nextSmallerElement(arr);
        for (int num : result) {
            System.out.print(num + " ");
        }
    }

    private static int[] nextSmallerElement(int[] arr) {
        int n = arr.length;
        int []ans = new int[n];
        Arrays.fill(ans, -1);
        Stack<Integer> stack = new Stack<>();
        for (int i = 0; i < n; i++) {
            while (!stack.isEmpty() && arr[i] <= arr[stack.peek()]) {
               int index = stack.pop();
                ans[index] = arr[i];
            }
            stack.push(i);
        }
        return ans;
    }
}
