package Frequency_Count_Pattern;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.IntStream;

public class TopKFrequentElements {
    public static void main(String[] args) {
//            [1, 1, 1, 2, 2, 3] and k = 2, the output should be [1, 2]
//            because 1 appears 3 times and 2 appears 2 times.
            int[] nums = {1, 1, 1, 2, 2, 3};
            int k = 2;
            int[] topKFrequentElements = findTopKFrequentElements(nums, k);
            System.out.println("Top " + k + " frequent elements: ");
            for (int num : topKFrequentElements) {
                System.out.print(num + " ");
            }
    }
//    If the array is sorted we don't need to sort that map w.r.t the value again
    private static int[] findTopKFrequentElements(int[] nums, int k) {
        Map<Integer, Integer> frequencyMap = new LinkedHashMap<>();
        for (int num : nums) {
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
        }

        return frequencyMap.entrySet()
                .stream()
//                .sorted((e1, e2) -> e2.getValue().compareTo(e1.getValue()))
                .limit(k)
                .mapToInt(Map.Entry::getKey)
                .toArray();
    }
}
