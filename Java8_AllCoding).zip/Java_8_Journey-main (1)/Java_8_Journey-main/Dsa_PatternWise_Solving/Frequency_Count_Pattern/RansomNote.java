package Frequency_Count_Pattern;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Map;

public class RansomNote {
    public static void main(String[] args) {
        String ransomNote = "bg";
        String magazine = "efjbdfbdgfjhhaiigfhbaejahgfbbgbjagbddfgdiaigdadhcfcj";
        boolean canConstruct = canConstruct(ransomNote, magazine);
        System.out.println("Can construct ransom note: " + canConstruct);
    }
//
    private static boolean canConstruct(String ransomNote, String magazine) {
//        char[] ransomNoteChars = ransomNote.toLowerCase().toCharArray();
////        char[] magazineChars = magazine.toLowerCase().toCharArray();
//        Arrays.sort(ransomNoteChars);
////        Arrays.sort(magazineChars);
//       String newRansomNote = new String(ransomNoteChars);
////       String newMagazine = new String(magazineChars);
//        System.out.println("newRansomNote = " + ransomNoteChars + " newMagazine = " + magazine);

        Map<Character, Integer> magazineMap = new java.util.HashMap<>();
        for(char c: magazine.toLowerCase().toCharArray()){
            magazineMap.put(c, magazineMap.getOrDefault(c,0) + 1);
        }
        for (char c: ransomNote.toLowerCase().toCharArray()){
            if (!magazineMap.containsKey(c) || magazineMap.get(c) <= 0){
                return false;
            }
            magazineMap.put(c, magazineMap.get(c) - 1);
        }
        return true;
    }
}
