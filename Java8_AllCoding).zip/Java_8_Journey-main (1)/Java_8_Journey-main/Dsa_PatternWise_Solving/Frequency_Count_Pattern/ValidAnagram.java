package Frequency_Count_Pattern;

import java.util.Map;

public class ValidAnagram {
    public static void main(String[] args) {
        System.out.println(isAnagramUsing1Map("anagram", "nagaram")); // true
        System.out.println(isAnagram("rat", "car")); // false
        System.out.println(isAnagramUsing1Map("malayalam", "malayalm")); // false
        System.out.println(isAnagramUsing1Map("listen", "silent")); // true
    }

    private static boolean isAnagram(String string1, String string2) {
        if (string1.length() != string2.length()) {
            return false;
        }
        Map<Character,Integer> frequencyMap = new java.util.HashMap<>();
        Map<Character,Integer> frequencyMap2 = new java.util.HashMap<>();
        for (char x : string1.toCharArray()){
            frequencyMap.put(x,frequencyMap.getOrDefault(x,0)+1);
        }
        for (char x : string2.toCharArray()){
            frequencyMap2.put(x,frequencyMap2.getOrDefault(x,0)+1);
        }
        for (Map.Entry<Character,Integer> entry : frequencyMap.entrySet()){
            if (!entry.getValue().equals(frequencyMap2.get(entry.getKey()))){
                return false;
            }

        }
        return true;
    }

    private static boolean isAnagramUsingSorting(String string1, String string2) {
        if (string1.length() != string2.length()) {
            return false;
        }
        char[] charArray1 = string1.toCharArray();
        char[] charArray2 = string2.toCharArray();
        java.util.Arrays.sort(charArray1);
        java.util.Arrays.sort(charArray2);
        return java.util.Arrays.equals(charArray1, charArray2);
    }

    private static boolean isAnagramUsingFrequencyCount(String string1, String string2) {
        if (string1.length() != string2.length()) {
            return false;
        }
        int[] frequency = new int[26]; // Assuming only lowercase letters
        for (char c : string1.toCharArray()) {
            frequency[c - 'a']++;
        }
        for (char c : string2.toCharArray()) {
            frequency[c - 'a']--;
            if (frequency[c - 'a'] < 0) {
                return false; // More occurrences in string2 than in string1
            }
        }
        return true;
    }

    private static boolean isAnagramUsing1Map(String string1, String string2) {
        if (string1.length() != string2.length()) {
            return false;
        }
        Map<Character,Integer> frequencyMap = new java.util.HashMap<>();
        for (char x : string1.toCharArray()){
            frequencyMap.put(x,frequencyMap.getOrDefault(x,0)+1);
        }
        for (char x : string2.toCharArray()){
            if (!frequencyMap.containsKey(x)){
                return false;
            }
            frequencyMap.put(x,frequencyMap.get(x)-1);
            if (frequencyMap.get(x) == 0){
                frequencyMap.remove(x); // Remove the key when its count reaches zero
            }
        }
        return frequencyMap.isEmpty(); // If the map is empty, then both strings are anagrams
    }
}
