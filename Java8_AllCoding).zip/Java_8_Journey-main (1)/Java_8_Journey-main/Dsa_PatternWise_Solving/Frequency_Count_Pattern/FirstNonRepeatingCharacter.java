package Frequency_Count_Pattern;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FirstNonRepeatingCharacter {
    public static void main(String[] args) {
        String str = "zswiss";
        char firstNonRepeatingChar = findFirstNonRepeatingCharacter(str);
        if (firstNonRepeatingChar != '\0') {
            System.out.println("The first non-repeating character is: " + firstNonRepeatingChar);
        } else {
            System.out.println("There are no non-repeating characters in the string.");
        }
    }

    private static char findFirstNonRepeatingCharacter(String str) {
        // Approach  using the frequency count hash map
//        LinkedHashMap<Character,Integer> map = new LinkedHashMap<>();
//        for (char x : str.toCharArray()){
//            map.put(x,map.getOrDefault(x,0)+1);
//        }
//        for (Map.Entry<Character,Integer> entry : map.entrySet()){
//            if (entry.getValue() == 1){
//                return entry.getKey();
//            }
//        }
//        return '\0'; // Return null character if no non-repeating character is found


//        Approach 2
//        int[] freq = new int[256]; // Assuming ASCII characters
//        for (char c : str.toCharArray()) {
//            freq[c]+=1;
//        }
//        Arrays.stream(freq).forEach(System.out::println); // Print frequency array for debugging
//        for (char c : str.toCharArray()) {
//            if (freq[c] == 1) {
//                return c;
//            }
//        }
//        return '\0'; // Return null character if no non-repeating character is found

//        return str.chars()
//                .mapToObj(c -> (char) c)
//                .collect(
//                        LinkedHashMap<Character, Integer>::new,
//                        (map, c) -> map.put(c, map.getOrDefault(c, 0) + 1),
//                        Map::putAll)
//                .entrySet()
//                .stream()
//                .filter(entry -> entry.getValue() == 1)
//                .map(Map.Entry::getKey)
//                .findFirst()
//                .orElse('\0');
//        List<String> x =  Arrays.stream(str.split("")).toList();
        List<Character> x = str.chars()
                .mapToObj(c -> (char) c)
                .toList();
         for (Character c : x) {
//             System.out.println("Last Index"+x.lastIndexOf(c));
             if (x.lastIndexOf(c)  == x.indexOf(c)) {
                 return c;
             }
         }
        return '\0'; // Return null character if no non-repeating character is found
    }
}
