package Frequency_Count_Pattern;

public class MissingElement {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 5, 6}; // o/p : 4
        int missingElement = findMissingElement(arr);
        System.out.println("Missing element: " + missingElement);
    }

    private static int findMissingElement(int[] arr) {
        int[] freq = new int[arr.length + 2]; // +2 to account for the missing element and 1-based indexing
        for (int num : arr) {
            freq[num]++;
        }

        for (int i = 1; i < freq.length; i++) {
            if (freq[i] == 0) {
                return i;
            }
        }
        return 0;
    }
}
