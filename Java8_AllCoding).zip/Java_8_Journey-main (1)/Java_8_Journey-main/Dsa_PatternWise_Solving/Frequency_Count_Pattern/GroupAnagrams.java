package Frequency_Count_Pattern;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class GroupAnagrams {
    public static void main(String[] args) {
        String[] strs = {"eat", "tea", "tan", "ate", "nat", "bat"};
       groupAnagrams(strs);
    }

    private static void groupAnagrams(String[] strs) {
        Map<String, List<String>> groupAnagramsMap = new java.util.HashMap<>();
        for (String str : strs) {
          String[] charsArray = str.split("");
            Arrays.sort(charsArray);
            String sortedArr = String.join("", charsArray);
            groupAnagramsMap.computeIfAbsent(sortedArr, k -> new java.util.ArrayList<>()).add(str);

//              groupAnagramsMap.put(sortedArr, groupAnagramsMap.getOrDefault(sortedArr, new java.util.ArrayList<>()));
//            groupAnagramsMap.put(sortedArr, groupAnagramsMap.getOrDefault(sortedArr, new java.util.ArrayList<>()).add(str)));
        }

        System.out.println("Grouped Anagrams: " + groupAnagramsMap.values());
    }
}
