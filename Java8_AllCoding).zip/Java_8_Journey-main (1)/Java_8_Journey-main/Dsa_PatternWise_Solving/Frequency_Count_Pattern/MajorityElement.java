package Frequency_Count_Pattern;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MajorityElement {
    public static void main(String[] args) {
        int[] nums = {3, 2, 3}; // o/p : 3
        int[] nums2 = {2,2,8,2,8,2,8,2,8,8,8,8}; // o/p : 8
        List<Integer> majorityElement = findMajorityElement(nums2);
        majorityElement.forEach(System.out::println);
    }

    private static List<Integer> findMajorityElement(int[] nums) {
        Map<Integer, Integer> frequencyMap = new java.util.HashMap<>();
        List<Integer> majorityElements = new ArrayList<>();
        int majorityCount = nums.length / 2;
        for(int num : nums){
            frequencyMap.put(num, frequencyMap.getOrDefault(num,0) + 1);
            if (frequencyMap.get(num) > majorityCount && !majorityElements.contains(num)){
                majorityElements.add(num);
            }
        }

            return majorityElements;
    }
}
