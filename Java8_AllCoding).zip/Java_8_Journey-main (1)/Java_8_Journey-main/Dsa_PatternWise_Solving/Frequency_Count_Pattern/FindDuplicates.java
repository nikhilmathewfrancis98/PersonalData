package Frequency_Count_Pattern;

import java.util.HashMap;

/**
 *  Here we have followed the frequency count approach
 */
public class FindDuplicates {
    public static void main(String[] args) {
        System.out.println(findDuplicates(new int[]{1, 2, 3, 4, 5,6,2}));
    }

    private static boolean findDuplicates(int[] ints) {
//        Approach 1 using stream
//        return java.util.Arrays.stream(ints).distinct().count() != ints.length;

//      Approach 2 using Set
//        Set<Integer> set = new java.util.HashSet<>();
//        for (int num : ints) {
//            if (!set.add(num)) {
//                return true; // Duplicate found
//            }
//        }
//       return false; // No duplicates

//        Approach 3 Frequency Count here we don't need to find the frequency and then
//        loop instead do if that key is present or not
        HashMap<Integer, Integer> frequencyMap = new HashMap<>();
        for (Integer x : ints) {
            if (frequencyMap.containsKey(x)) {
                return true; // Duplicate found
            }
            frequencyMap.put(x, frequencyMap.getOrDefault(x, 0) + 1);
        }

        return false;
    }
    
}
