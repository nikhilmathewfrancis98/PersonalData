package Twopointers;

public class MoveZerosToEnd {
    public static void main(String[] args) {
//        int[] arr = {1,0,3,12,0,13,0};
//        int[] arr = {0, 1, 1, 0, 0};
        int[] arr = {1, 1, 0, 0, 1, 1};
        moveZerosToEnd(arr);
    }
//    Move zeros to end without changing the order of non-zero elements
    private static void moveZerosToEnd(int[] arr) {
        int nonZeroIndex = 0;
        for(int i = 0; i < arr.length; i++){
            if(arr[i] != 0){
                int temp = arr[nonZeroIndex];
                arr[nonZeroIndex] = arr[i];
                arr[i] = temp;
                nonZeroIndex++;
            }
        }

        for(int num : arr){
            System.out.print(num + " ");
        }
    }

//    Move Zeros to first without changing the order of non-zero elements
    private static void moveZerosToFirst(int[] arr) {
        int nonZeroIndex = arr.length - 1;
        for(int i = arr.length - 1; i >= 0; i--){
            if(arr[i] != 0){
                int temp = arr[nonZeroIndex];
                arr[nonZeroIndex] = arr[i];
                arr[i] = temp;
                nonZeroIndex--;
            }
        }
//
//        for(int num : arr){
//            System.out.print(num + " ");
//        }

//        int nonZeroIndex = 1;
//        for (int i = 0; i < arr.length - 1 && nonZeroIndex < arr.length;) {
//            if (arr[nonZeroIndex] == 0) {
//                int temp = arr[nonZeroIndex];
//                arr[nonZeroIndex] = arr[i];
//                arr[i] = temp;
//                i++;
//            }
//            nonZeroIndex++;
//        }

        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
}
