package main.java.com.LinkedLists;

public class Demo {
    public static void main(String[] args) {
        SinglyLinkedList<Integer> list = new SinglyLinkedList<>();
        list.add(10);
        list.add(20);
        System.out.println(list.getHead());
        System.out.println(list.getTail());
//        list.addFirst(5);     // [5, 10, 20]
//        list.add(2, 15);      // [5, 10, 15, 20]
//        System.out.println(list.get(2)); // 15
//        list.remove((Integer)10);        // [5, 15, 20]
//        list.remove(0);                  // [15, 20]
//        System.out.println(list.getLast());  // 20
//        for (int x : list) System.out.print(x + " "); // 15 20
    }
}