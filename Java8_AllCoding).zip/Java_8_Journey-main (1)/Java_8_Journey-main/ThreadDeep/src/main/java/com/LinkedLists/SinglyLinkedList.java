package main.java.com.LinkedLists;


import java.util.Iterator;
import java.util.NoSuchElementException;

public class SinglyLinkedList<E> implements Iterable<E> {

    // Node definition
    private static class Node<E> {
        E value;
        Node<E> next;
        Node(E value) { this.value = value; }
    }

    private Node<E> head;

    private Node<E> tail; // last node (optional but makes addLast O(1))

    private int size;

    // --- Basic queries ---
    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }

    // --- Add operations ---
    public void add(E e) { // append to end
        addLast(e);
    }

    public void addFirst(E e) {
        Node<E> node = new Node<>(e);
        node.next = head;
        head = node;
        if (tail == null) tail = head;
        size++;
    }

    public void addLast(E e) {
        Node<E> node = new Node<>(e);
        if (tail == null) {
            head = tail = node;
        } else {
            tail.next = node;
            tail = node;
        }
        size++;
    }

    public void add(int index, E e) {
        checkPositionIndex(index); // index in [0..size]
        if (index == 0) { addFirst(e); return; }
        if (index == size) { addLast(e); return; }
        Node<E> prev = nodeAt(index - 1);
        Node<E> node = new Node<>(e);
        node.next = prev.next;
        prev.next = node;
        size++;
    }

    // --- Get / Set ---
    public E get(int index) {
        checkElementIndex(index); // index in [0..size-1]
        return nodeAt(index).value;
    }

    public E set(int index, E e) {
        checkElementIndex(index);
        Node<E> n = nodeAt(index);
        E old = n.value;
        n.value = e;
        return old;
    }

    // --- Remove operations ---
    public E removeFirst() {
        if (head == null) throw new NoSuchElementException();
        E val = head.value;
        Node<E> next = head.next;
        // Help GC
        head.value = null;
        head.next = null;
        head = next;
        if (head == null) tail = null;
        size--;
        return val;
    }

    public E removeLast() {
        if (head == null) throw new NoSuchElementException();
        if (head == tail) {
            E val = head.value;
            head.value = null;
            head = tail = null;
            size--;
            return val;
        }
        Node<E> prev = head;
        while (prev.next != tail) {
            prev = prev.next;
        }
        E val = tail.value;
        prev.next = null;
        tail.value = null;
        tail = prev;
        size--;
        return val;
    }

    public E remove(int index) {
        checkElementIndex(index);
        if (index == 0) return removeFirst();
        Node<E> prev = nodeAt(index - 1);
        Node<E> target = prev.next;
        prev.next = target.next;
        if (target == tail) tail = prev;
        E val = target.value;
        // Help GC
        target.value = null;
        target.next = null;
        size--;
        return val;
    }

    public boolean remove(Object o) {
        Node<E> prev = null;
        Node<E> curr = head;
        while (curr != null) {
            if (eq(curr.value, o)) {
                if (prev == null) { // removing head
                    head = curr.next;
                    if (head == null) tail = null;
                } else {
                    prev.next = curr.next;
                    if (curr == tail) tail = prev;
                }
                // Help GC
                curr.value = null;
                curr.next = null;
                size--;
                return true;
            }
            prev = curr;
            curr = curr.next;
        }
        return false;
    }

    // --- Search ---
    public boolean contains(Object o) {
        return indexOf(o) != -1;
    }

    public int indexOf(Object o) {
        int i = 0;
        for (Node<E> n = head; n != null; n = n.next) {
            if (eq(n.value, o)) return i;
            i++;
        }
        return -1;
    }

    // --- Clear ---
    public void clear() {
        // Unlink all nodes to help GC
        Node<E> curr = head;
        while (curr != null) {
            Node<E> next = curr.next;
            curr.value = null;
            curr.next = null;
            curr = next;
        }
        head = tail = null;
        size = 0;
    }

    // --- Iterator ---
    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            private Node<E> curr = head;
            @Override
            public boolean hasNext() { return curr != null; }
            @Override
            public E next() {
                if (curr == null) throw new NoSuchElementException();
                E val = curr.value;
                curr = curr.next;
                return val;
            }
        };
    }

    // --- Helpers ---
    private Node<E> nodeAt(int index) {
        Node<E> n = head;
        for (int i = 0; i < index; i++) n = n.next;
        return n;
    }

    private static boolean eq(Object a, Object b) {
        return (a == b) || (a != null && a.equals(b));
    }

    private void checkElementIndex(int index) {
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
    }

    private void checkPositionIndex(int index) {
        if (index < 0 || index > size)
            throw new IndexOutOfBoundsException(outOfBoundsMsg(index));
    }

    private String outOfBoundsMsg(int index) {
        return "Index: " + index + ", Size: " + size;
    }

    // Convenience
    public E getFirst() {
        if (head == null) throw new NoSuchElementException();
        return head.value;
    }

    public E getLast() {
        if (tail == null) throw new NoSuchElementException();
        return tail.value;
    }

    public Node<E> getHead() {
        return head;
    }

    public Node<E> getTail() {
        return tail;
    }

}