package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

class Todo{
    private String name;
    private  String description;
    private LocalDate startDate;
//    private static LocalDate currentDate= Date;

    public Todo(String name, LocalDate startDate, LocalDate endDate,String description) {
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.description=description;
        this.completed= LocalDate.now().isAfter(endDate);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return this.description;
    }

    private LocalDate endDate;
    private boolean completed;
}
class TodoList{
    private static List<Todo> todoList;
   private static final BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
//    private static final Predicate<Todo> isTodoNull= Objects::isNull;
    public void createTodo() throws IOException {
        try {
        System.out.println("Enter the Todo List details:");
        System.out.println("Name : ");
        String name=br.readLine();
        System.out.println("Description : ");
        String description=br.readLine();
            System.out.print("ENTER the Start and End Date (m/d/yyyy ): ");
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("M/d/yyyy");
            String startDate = br.readLine();
            LocalDate startdate = LocalDate.parse(startDate, dateFormat);

            String endDate = br.readLine();
            LocalDate enddate = LocalDate.parse(endDate, dateFormat);
            todoList.add(new Todo(name,startdate,enddate,description));

        }
        catch(Exception e) {
            e.printStackTrace(System.out);
        }
    }
    public  void ListAllTodos(){
        System.out.println("Listing all the Todos: \n");
        for (Todo x:todoList)
            System.out.println("Name: "+x.getName()+
            "\nDescription: "+x.getDescription()+
                    "\nStart Date: "+x.getStartDate()+
                    "\nEnd Date: "+x.getEndDate()+
                    "\nCompleted: "+x.isCompleted());
    }

    public  TodoList() {
        todoList=new ArrayList<>();
    }

    public  void CloseAllTodo(){
        System.out.println("The List is null and");
        if (todoList == null){
            System.out.println("The List is null and");
        }else {
//            todoList.stream().filter(Todo::isCompleted)
//                    .collect(Collectors.toCollection(ArrayList::new));
            todoList.removeIf(Todo::isCompleted);
        }

    }
    public  void CloseTodo() throws IOException {
        System.out.println("Enter the Todo to get deleted:");
        br.readLine();
    }
    public  void findTodo(){

    }

}
public class Main {
    public static void main(String[] args) throws IOException {
        TodoList todoList=new TodoList();
        boolean condition =true;
        while(condition){
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter the options : \n"+
                    "(1) -> Create Todo \n" +
                    "(2) -> List All Todo \n"+
                    "(3) -> Close All Todos \n" +
                    "(4) -> Close A Todo \n" +
                    "(5) -> Find A Todo \n");
            int input=sc.nextInt();
            switch(input){
                case 1 -> todoList.createTodo();
                case 2 -> todoList.ListAllTodos();
                case 3 -> todoList.CloseAllTodo();
                case 4 -> todoList.CloseTodo();
                case 5 -> todoList.findTodo();
                default -> condition = false;
            }
        }

    }
}