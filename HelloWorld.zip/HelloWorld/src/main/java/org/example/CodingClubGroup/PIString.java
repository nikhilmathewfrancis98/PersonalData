package org.example.CodingClubGroup;

import java.util.Objects;

public class PIString {
    public static void main(String[] args) {
        String input="pix";
        StringBuilder res = new StringBuilder();

        for (int i=0;i<input.length();){
            if (Objects.equals(input.charAt(i), 'p') && Objects.equals(input.charAt(i+1), 'i')){
                res.append("3.14");
                i+=2;
            }else {
                res.append(input.charAt(i));
                i++;
            }

        }
        System.out.println(res);
    }
}
