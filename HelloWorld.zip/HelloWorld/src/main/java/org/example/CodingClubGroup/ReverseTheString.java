package org.example.CodingClubGroup;

import java.util.Arrays;
import java.util.Objects;

/**
 *  reverse the String that is given
 *  the string contains a sentence separated by '.' so do not reverse individually
 *  but reverse the words
 *  I/p = i.like.this.program.very.much
 *  O/p = much.very.program.this.like.i
 */

public class ReverseTheString {
    public static void main(String[] args) {
        String input = "its.like.this.program.very.much";
        String [] res=input.split("\\.");
        StringBuilder result=new StringBuilder();

        for (int i=res.length - 1;i>=0;i--){
           result.append(res[i]);
            if(i !=0 ) {
                result.append('.');
            }

        }
        System.out.println(result);
    }
}

/*
 *  Logic 1:
 *   String input = "its.like.this.program.very.much";
        String input1=".";
        input1+=input;
        StringBuilder result=new StringBuilder();
        int j=input1.length()-1;
        for (int i=input1.length()-1;i>=0;){
            if(!Objects.equals(input1.charAt(i), '.')){
                i--;
            }else{
                int x=i+1;
                int y=j;
                while(x<=y){
                    result.append(input1.charAt(x));
                    x++;
                }
                result.append(input1.charAt(i));
                i-=1;
                j=i;
            }

        }
        result.setCharAt(result.length()-1,' ');
        System.out.println(result);
 */