package org.example;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CountOccuranceOfChar {
    public static void main(String[] args) {
//        String s="geeksforgeeks";
//        char c='e';
//        Optional<Map.Entry<String, Long>> result=Stream.of(s.split(""))
//               .collect(Collectors.groupingBy(item -> item, Collectors.counting()))
//                       .entrySet().stream()
//                .filter(entry -> {
//                    String str= String.valueOf(c);
//                    return str.equals(entry.getKey());
//                } )
//               .findFirst();
//        result.ifPresent(entry -> System.out.println(entry.getValue()));


        List<String> items = Arrays.asList("apple", "banana",
                "cherry", "date", "elderberry", "fig", "grape"
        ,"apple2", "banana2",
                "cherry2", "dates2", "elderberry2", "fig2", "grape2");


//        Map<Integer, List<String>> re = items.stream()
//                .collect(Collectors.groupingBy(String::length));
        // {3=[fig], 4=[date, fig2], 5=[apple, grape], 6=[banana, cherry, apple2, dates2, grape2], etc...
        // Group by first letter and then by length of the string
        Map<Character, Map<Integer, List<String>>> re = items.stream()
                .collect(Collectors.groupingBy(item -> item.charAt(0),
                        Collectors.groupingBy(String::length)));
        // the above is the 2 levels of grouping
        System.out.println(re);

    }
}
