package org.example;

import java.util.*;

class Solution15 {
    public static List<List<Integer>> threeSum(int[] nums) {
        List<List<Integer>> res=new ArrayList<>();
        Arrays.sort(nums);
        for (int i=0;i<nums.length;i++){
            if (i != 0 && nums[i] == nums[i - 1]) continue;
            int end = nums.length - 1;
            int start = i+1;
            int target=nums[i];
            while (start < end) {
              if (nums[start] + nums[end] +target > 0) {
                  end--;
                  continue;
              }

              if (nums[start] + nums[end] +target < 0) {
                  start++;
                  continue;
              }


              res.add(Arrays.asList(target, nums[start], nums[end]));
              start++;
              end--;


              while (start <= end && nums[start] == nums[start - 1]) {
                  start++;
              }
          }

        }
        return res;
    }
    }
public class ThreeSum {
    public static void main(String[] args) {
        int[] arr=new int[]{-1,0,1,2,-1,-4}; //[[-1,-1,2],[-1,0,1]]
        int[] arr2=new int[]{0,1,1}; // []
        int [] arr3=new int[]{1,-1,-1,0}; // [[1,0,1]]
        for (List<Integer> c:Solution15.threeSum(arr3)){
            System.out.println(c.toString());
        }

    }
}
/**
 *  if(nums.length==3 && nums[0]+nums[1]+nums[2] == 0){
 *              fineList.add(new ArrayList<>(Arrays.asList(nums[0],nums[1],nums[2])));
 *              return fineList;
 *         }
 *         for(int i=0;i<nums.length;i++){
 *             // int sum = 0;
 *             for(int j=2;j<nums.length;j++){
 *                 // sum=nums[j];
 *                 for (int k=j+1;k< nums.length;k++){
 *                     if (k == j) continue;
 *                     if(nums[i]+nums[j]+nums[k-j] == 0){
 *                         fineList.add(new ArrayList<>(Arrays.asList(nums[i],nums[j],nums[k-j])));
 *                     }
 *                 }
 *
 *             }
 *         }
 *
 *         class Solution {
 *     public List<List<Integer>> threeSum(int[] nums) {
 *       Arrays.sort(nums);
 *        List<List<Integer>> res=new ArrayList();
 *         Set<List<Integer>> validate=new HashSet<>();
 *         for(int i=0;i<nums.length - 2;i++){
 *             for(int j=i+1,k=nums.length - 1; j < k ;){
 *                 int sum=nums[i]+nums[j]+nums[k];
 *                 if(sum > 0){
 *                     k--;
 *                 }else if(sum < 0){
 *                     j++;
 *                 }else{
 *                     // List<Integer> list= new ArrayList(Arrays.asList(nums[i],nums[j],nums[k]));
 *                     // Collections.sort(list);
 *                     // res.add(list);
 *                     if (validate.add(Arrays.asList(nums[i] ,nums[j],nums[k])))
 *                          res.add(Arrays.asList(nums[i] ,nums[j],nums[k]));
 *                     j++;
 *                     k--;
 *                 }
 *             }
 *         }
 *         return res;
 *     }
 * }
 *
 * class Solution {
 *     public List<List<Integer>> threeSum(int[] nums) {
 *       Arrays.sort(nums);
 *        Set<List<Integer>> res=new HashSet();
 *         for(int i=0;i<nums.length - 2;i++){
 *             for(int j=i+1,k=nums.length - 1; j < k ;){
 *                 int sum=nums[i]+nums[j]+nums[k];
 *                 if(sum > 0){
 *                     k--;
 *                 }else if(sum < 0){
 *                     j++;
 *                 }else{
 *                     List<Integer> list= new ArrayList(Arrays.asList(nums[i],nums[j],nums[k]));
 *                     Collections.sort(list);
 *                     res.add(list);
 *                     j++;
 *                     k--;
 *                 }
 *             }
 *         }
 *         return res.stream().collect(Collectors.toList());
 *     }
 * }
 *
 *
 * 27 ms
 * class Solution {
 *     public List<List<Integer>> threeSum(int[] nums) {
 *         int n = nums.length;
 *         List<List<Integer>> res = new ArrayList<>();
 *         Arrays.sort(nums);
 *
 *
 *         for (int i = 0; i < n - 2 && nums[i] <= 0; i++) {
 *
 *             if (i != 0 && nums[i] == nums[i - 1]) continue;
 *             twoSum(i + 1, -nums[i], nums, res);
 *         }
 *
 *         return res;
 *     }
 *
 *     private void twoSum(int start, int target, int[] nums, List<List<Integer>> res) {
 *         int end = nums.length - 1;
 *
 *
 *         while (start < end) {
 *             if (nums[start] + nums[end] > target) {
 *                 end--;
 *                 continue;
 *             }
 *
 *             if (nums[start] + nums[end] < target) {
 *                 start++;
 *                 continue;
 *             }
 *
 *
 *             res.add(Arrays.asList(-target, nums[start], nums[end]));
 *             start++;
 *             end--;
 *
 *
 *             while (start <= end && nums[start] == nums[start - 1]) {
 *                 start++;
 *             }
 *         }
 *     }
 * }
 *
 * 9ms
 * return new AbstractList<List<Integer>>() {
 *             public List<Integer> get(int i) {init(); return result.get(i);}
 *             public int size() {init(); return result.size();}
 *             void init() {
 *                 if (result != null) return;
 *                 Arrays.sort(nums);
 *                 result = new ArrayList<>();
 *                 for(int i=0; i<nums.length - 2 ; i++) {
 *                     if (i > 0 && nums[i] == nums[i - 1]) continue;
 *                     int l = i+1;
 *                     int r = nums.length - 1;
 *                     int target = -nums[i];
 *                     while(l<r) {
 *                         int sum = nums[l] + nums[r];
 *                         if (sum == target ) {
 *                             result.add(Arrays.asList(nums[i], nums[l], nums[r]));
 *                             l++;
 *                             r--;
 *                             while (l < r && nums[l] == nums[l - 1]) l++;
 *                             while (l < r && nums[r] == nums[r + 1]) r--;
 *                         }
 *                         else if (sum < target) {
 *                             l++;
 *                         } else {
 *                             r--;
 *                         }
 *                     }
 *                 }
 *             }
 *         };
 */