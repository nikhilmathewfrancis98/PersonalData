package org.example.DSA2;

public class CountFactors {
    public static void main(String[] args) {
        System.out.println(countFactors(100));
    }    // Optimized -> n = 100    // 1 <= N <= 10^18 - > 1 - 1000000    // TLE -  TC > 10^9

    private static int countFactors(int n) {
        int count = 0;
        for (int i = 1; i <= n / i; i++) {
            if (i * i == n)
                count++;
            else if (n % i == 0)
                count += 2;
        }
        return count;
    }
}
// Optimized approch to soln
// /*    n = 24    24 -> 1, 2, 3, 4, 6, 8, 12, 24
// i = 4;    n/i = j    n = i*j;    24/4 = 6
// i   n/i  =   j
// ---------------
// 1   24/1 = 24
// 2   24/2 = 12
// 3   24/3 = 8
// 4   24/4 = 6
// 6   24/6 = 4
// 8   24/8 = 3
// 12  24/12 = 2
// 24  24/24 = 1
// 100 -> 1, 2, 4, 5, 10, 25, 50 ,100
// i   n/i = j    --------------
// 1   100/1 = 100
// 2   100/2 = 50
// 4   100/4 = 25
// 5   100/5 = 20
// 10  100/10 = 10
// 20  100/20 = 5
// 25  100/25 = 4
// 50  100/50 = 2
// 100 100/100 = 1

// */    // Understand the prblm
// try BF    // try optimized    // - analysed the BF
// - breakdown the BF to map to optimized approch    // implement it}