package org.example;

import java.util.*;

class Student{
   private int id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private String name;
}
public class ComparableComparator {
    private static final Comparator <String> stringComparator2=Comparator.comparing(String::new);
    private static final Comparator <Student> stringComparator=Comparator.comparing(Student::getName);
    public static void main(String[] args) {
        List<Student> list=new ArrayList<>(
                Arrays.asList(
                        new Student(1,"Nikhil"),
                        new Student(2,"Mathew"),
                        new Student(3,"Francis"),
                        new Student(4,"Emil"),
                        new Student(5,"Alan")
                        ));
        List<String> list2=new ArrayList<>(
                Arrays.asList(
                        "Nikhil",
                        "Mathew", "Francis",
                        "Emil",
                       "Alan"
                ));
        list.sort(stringComparator);
        list2.sort(stringComparator2);
        System.out.println(list2.toString());
        for (Student x: list)
            System.out.println(x.getName());
    }
}
