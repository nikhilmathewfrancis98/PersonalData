package org.example.DSA;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

class Solution2 {
    public int lastStoneWeight(int[] stones) {
        Integer[] integerArray = Arrays.stream(stones).boxed().toArray(Integer[]::new);
        List<Integer> arr = new ArrayList<>(Arrays.asList(integerArray));
        Collections.sort(arr);
        while (arr.size() > 1) {
            // Get the two largest elements
            int i = arr.size() - 2;
            int j = arr.size() - 1;
            int newStone = arr.get(j) - arr.get(i);

            // Remove the two largest elements
            arr.remove(j);
            arr.remove(i);
            if (newStone > 0) {
                arr.add(newStone);
                Collections.sort(arr);
            }
        }

        return arr.isEmpty() ? 0 : arr.get(0);

    }
}
public class LastStoneWeight {
    public static void main(String[] args) {
        int[] arr=new int[]{1};
        Solution2 x=new Solution2();
        System.out.println(x.lastStoneWeight(arr));
    }
}
