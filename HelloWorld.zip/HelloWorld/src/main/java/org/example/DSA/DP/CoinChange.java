package org.example.DSA.DP;

import java.util.Arrays;

class Solution322{
    public static int coinChange(int[] coins, int amount) {
        int[] amt=new int[amount + 1];
        Arrays.fill(amt,Integer.MAX_VALUE);
        Arrays.sort(coins);
        int min;
        amt[0]=0;
        // amt[1]=1;
        for (int i=1;i < amt.length;i++){
            for (int coin : coins) {
                if (i - coin < 0) break;
                if (amt[i - coin] != Integer.MAX_VALUE) {
                    amt[i]= Math.min(amt[i], amt[i - coin] + 1);

                }
            }

        }
        System.out.println(Arrays.toString(amt));
        return amt[amount] == Integer.MAX_VALUE?-1: amt[amount];
    }
}
public class CoinChange {
    public static void main(String[] args) {
        int [] arr={2,3,5};
        int amount=10;
        System.out.println(Solution322.coinChange(arr,amount));
    }
}
/**
 *  Logic similar mostly to the greedy approach
 *
 *    Arrays.sort(coins);
 *         int count=0;
 *         if (amount == 0)
 *             return 0;
 *         for (int i=coins.length-1;i>=0;){
 *             if ( amount - coins[i] < 0){
 *                 i--;
 *             }else {
 *                 count++;
 *                 amount-=coins[i];
 *             }
 *
 *         }
 *
 *         return (amount == 0)?count:-1;
 *
 *
 *         Dynamic programming logic
 *
 *          int[] amt=new int[amount + 1];
 *        Arrays.fill(amt,Integer.MAX_VALUE);
 *         Arrays.sort(coins);
 *         amt[0]=0;
 *         amt[1]=1;
 *        for (int i=2;i < amt.length;i++){
 *            for (int coin : coins) {
 *                if (i - coin < 0) break;
 *                if (amt[i - coin] != Integer.MAX_VALUE) {
 *                    amt[i] = Math.min(amt[i],amt[i - coin] + 1);
 *                }
 *            }
 *
 *        }
 *        return amt[amount] == Integer.MAX_VALUE?-1: amt[amount];
 *
 *
 *        Logic My code revised :-
 *
 *        int[] amt = new int[amount + 1];
 * Arrays.sort(coins);
 * amt[0] = 0;
 *
 * for (int i = 1; i <= amount; i++) {
 *     int min_Coins = Integer.MAX_VALUE;
 *     for (int coin : coins) {
 *         if (i - coin >= 0 && amt[i - coin] != Integer.MAX_VALUE) {
 *             min_Coins = Math.min(min_Coins, amt[i - coin] + 1);
 *         }
 *     }
 *     amt[i] = min_Coins;
 * }
 *
 * return amt[amount] == Integer.MAX_VALUE ? -1 : amt[amount];
 */