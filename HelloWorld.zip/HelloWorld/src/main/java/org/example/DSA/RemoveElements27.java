package org.example.DSA;
class Solution27 {
    public static int removeElement(int[] nums, int val) {
        int i=0,j=0;

        while(j < nums.length){
            if(nums[j] == val){
                j++;
            }else{
                nums[i] = nums[j];
                i++;
                j++;
            }
        }
        return i;
    }
}
public class RemoveElements27 {
    public static void main(String[] args) {
        int arr[]=new int[]{0,1,2,2,3,0,4,2};
        int val=2;
        System.out.println(Solution27.removeElement(arr,val));
    }
}
