package org.example.DSA;

import com.sun.security.jgss.GSSUtil;

import java.util.*;
import java.util.stream.Collectors;

class Solutions {
    public int removeDuplicates(int[] nums) {
        int k=0;
//        int [] expectedNums=new int[nums.length];
//        expectedNums = Arrays.stream(nums).boxed()
//                .distinct()
//                .collect(Collectors.toCollection(LinkedHashSet::new))
//                .stream()
//               .mapToInt(Integer::intValue)
//                .toArray();
//        k=expectedNums.length;
//        System.out.println(Arrays.toString(expectedNums));
//        System.out.println(Arrays.toString(nums));


//        List<Integer> addOns=new ArrayList<>();
//        List<Integer> expected=new ArrayList<>();
//       for (int i=0;i<nums.length ;i++){
//           if (expected.contains(nums[i]) ){
//               addOns.add(nums[i]);
//           }else {
//               expected.add(nums[i]);
//           }
//       }
//        k=expected.size();
//        expected.addAll(addOns);
//        int z=0;
//        for (int x:expected) {
//            nums[z] = x;
//            z++;
//        }
//        System.out.println(Arrays.toString(nums));
//        int fast = 0;
//        int slow = 0;
//        while (fast < nums.length) {
//            if (fast > 0 && nums[fast] == nums[fast - 1]) {
//                fast++;
//            } else {
//                nums[slow] = nums[fast];
//                // set.add(nums[fast]);
//                fast++;
//                slow++;
//            }
//        }
//        System.out.println(Arrays.toString(nums));

        int temp=0,count=0;
        for (int i=0,j=1; i < nums.length - 1 && j < nums.length;){
            if ( nums[i] == nums[j]){
                ++j;

            }else {
                count+=1;
                temp=nums[i + 1];
                nums[i + 1] = nums[j];
                nums[j] = temp;
                ++i;
                ++j;

            }
        }
        System.out.println(Arrays.toString(nums));
        return ++count;


//        int t = 0, temp = -101;
//        for (int i = 0; i < nums.length; i++) {
//            if (nums[i] != temp) {
//                nums[t++] = nums[i];
//                temp = nums[i];
//            }
//        }
//        System.out.println(Arrays.toString(nums));
//        return t;
    }
}
public class RemoveDuplicatesFromSortedArray {
    public static void main(String[] args) {
        Solutions s= new Solutions();
        int [] arr=new int[]{1,1,2};
        int[] arr2=new int[]{0,0,1,1,1,2,2,3,3,4};
        int[] arr3=new int[]{1,2,2,2,3};
        System.out.println(s.removeDuplicates(arr3));
    }
}
