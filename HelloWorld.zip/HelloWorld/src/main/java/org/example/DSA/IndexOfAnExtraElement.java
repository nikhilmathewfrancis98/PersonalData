package org.example.DSA;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

class SolutionIndexOfExtraElement{
    public static int findExtra(int arr1[], int arr2[]) {
        // add code here.
//        int index = 0;
//        Set<Integer> arr=new HashSet<>();
//        for (int i=0;i < arr2.length;){
//           arr.add( arr2[i]);
//        }
//        for (int x=0;x<arr1.length;x++) {
//            if (arr.add(arr1[x])) {
//                index = x;
//                break;
//            }
//        }
//        return index;

//        int index = 0; Logic 2
//        HashSet<Integer> arr= Arrays.stream(arr2).boxed()
//        .collect(Collectors.toCollection(HashSet::new));
//        for (int x=0;x<arr1.length;x++) {
//            if (arr.add(arr1[x])) {
//                index = x;
//                break;
//            }
//        }
//        return index;

//        int index=0; Logic 3
//        for (int i=0,j=0;i < arr1.length || j< arr2.length;){
//            if (i == arr1.length - 1){
//                index=i;
//                break;
//            }
//             if (arr1[i] != arr2[j]){
//                 index=i;
//                 break;
//             }
//             i++;
//             j++;
//        }
//        return index;
//        HashSet<Integer> set=new HashSet<>();
        for (int i= arr1.length -1,j= arr2.length-1;j>=0;i--,j--){ // Logic 4
            if (arr1[i] != arr2[j]){
                return i;
            }
        }
        return 0;
    }
}
public class IndexOfAnExtraElement {
    public static void main(String[] args) {
        int [] arr=new int[]{2,4,6,8,9,10,12};
        int [] arr1=new int[]{2,4,6,8,10,12};
        System.out.println(SolutionIndexOfExtraElement.findExtra(arr,arr1));
    }
}
