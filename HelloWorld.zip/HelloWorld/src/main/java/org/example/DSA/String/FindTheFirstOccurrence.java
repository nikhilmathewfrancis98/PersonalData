package org.example.DSA.String;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Solution28{
    public static int strStr(String haystack, String needle) {
    return  haystack.indexOf(needle);
    }
}
public class FindTheFirstOccurrence {
    public static void main(String[] args) {
        String haystack="sadbutsad";
        String needle="sad";
        System.out.println(Solution28.strStr(haystack,needle));
    }
}

/**
 *  By coding
 *
 *    if(needle.isEmpty()){
 *             return 0;
 *         }
 *
 *         int haylength = haystack.length();
 *         int needlelength = needle.length();
 *
 *         for(int i =0; i<= haylength - needlelength;i++){
 *             if (haystack.substring(i, i + needlelength).equals(needle)) {
 *                 return i;
 *             }
 *         }
 *         return -1;
 */
