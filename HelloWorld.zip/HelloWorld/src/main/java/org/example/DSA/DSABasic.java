package org.example.DSA;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Given an integer array nums sorted in non-decreasing order,
 * return an array of the squares of each number sorted in non-decreasing order.
 * Input: nums = [-4,-1,0,3,10]
 * Output: [0,1,9,16,100]
 * Explanation: After squaring, the array becomes [16,1,0,9,100].
 * After sorting, it becomes [0,1,9,16,100].
 */
public class DSABasic {
    public static void main(String[] args) {
        int []nums= new int[]{-4,-1,0,3,10};
        Arrays.stream(nums)
                .mapToDouble(x -> Math.pow(x,2))
                .mapToInt(x->(int)x)
                .sorted()
                .boxed()
                .collect(Collectors.toList()).forEach(System.out::println);
    }
}
