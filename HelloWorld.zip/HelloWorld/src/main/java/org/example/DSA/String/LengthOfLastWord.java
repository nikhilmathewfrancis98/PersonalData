package org.example.DSA.String;

class  Solution58{
    public static int lengthOfLastWord(String s) {
        int count=0;
       for (int i=s.trim().length() - 1;i>0;i--)
           if (s.charAt(i) == ' ')
               return count;
          count++;

      return count;
    }
}
public class LengthOfLastWord {
    public static void main(String[] args) {
        String s="Hello World"; // 5
        String s1="   fly me   to   the moon  "; // 4
        String s2="luffy is still joyboy"; // 6
        System.out.println(Solution58.lengthOfLastWord(s));
    }
}

/**
 *  Logic 1
 *       String[]c= s.trim().split(" ");
 *       return c[c.length - 1].length();
 */