package org.example.DSA;

/**
 *  This is the question which needs the subscription in leetcode
 *  The question is find the minimum path distance between the 2 words we are provided with
 *  We have give a sting array
 *
 *    Logic No 1 :-
 *         int shortest;
 *         List<String> list=new ArrayList<>(Arrays.asList(words));
 *         shortest=Math.abs(list.lastIndexOf(word2) - list.lastIndexOf(word1));
 *          return shortest;
 *
 */

class Solution243{
    public static int shortestDistance(String[] words, String word1, String word2) {
        // Complexity O(n) time, O(1) space
        int start=-1,end=-1,shortest=0;
        for (int i=0;i< words.length;i++){
            if (words[i] == word1){
                start=i;
            } else if (words[i] == word2) {
                end=i;
            }
            if (start != -1 && end!= -1){ // in each iteration we need to check if we get the shortest distance
                shortest = Math.min(Math.abs(start - end),shortest);
            }
        }

        return shortest;
    }
}
public class ShortestWordDistance {
    public static void main(String[] args) {
    String []arr={"practice", "makes", "perfect", "coding", "makes"};
        System.out.println(Solution243.shortestDistance(arr,"practice","coding"));
    }
}
