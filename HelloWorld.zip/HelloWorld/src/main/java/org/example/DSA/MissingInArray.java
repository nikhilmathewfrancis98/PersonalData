package org.example.DSA;
class MissingSolution{
    public static int missingNumber(int []arr) {
        int n=arr.length + 1,sum=0;
        for (int i:arr)
            sum+=i;
        return (n * (n + 1) / 2 - sum);
    }
}
public class MissingInArray {
    public static void main(String[] args) {
        int []arr=new int[]{1, 2, 3, 5};
        System.out.println(MissingSolution.missingNumber(arr));
    }
}
