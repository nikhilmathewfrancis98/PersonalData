package org.example.DSA;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Solution88 {
    public static void merge(int[] nums1, int m, int[] nums2, int n) {
//        int i = m - 1; // Pointer for nums1
//        int j = n - 1; // Pointer for nums2
        int k = m + n - 1; // Pointer for the merged array
        while(n>0 && m>0){
            if (nums1[m-1] > nums2[n-1]){
                nums1[k] = nums1[m-1];
                m--;
            }else {
                nums1[k] = nums2[n-1];
                n--;
            }
            k--;
        }
        // Merge nums1 and nums2 from the end
        System.out.println(Arrays.toString(nums1));
    }
}

public class MergeSortedArray {
    public static void main(String[] args) {
        int[] nums2 =new int[]{2,5,6};
        int[] nums1=new int[]{1,2,3,4,0,0,0};

        Solution88.merge(nums1, nums1.length - nums2.length, nums2, nums2.length);
    }
}

/**
 * } else if (nums1[i] == 0) {
 *                 nums1[i] = nums2[j];
 *                 System.out.println(nums1[i]);
 *                 j++;
 *             } else if (nums1[i] > nums2[j]) {
 *                 temp = nums1[i];
 *                 nums1[i]=nums2[j];
 *                 nums2[j]=temp;
 *                 System.out.println(nums1[i]);
 *                 i++;
 *             }
 *
 *          //        boolean flag=true;
 *         int temp;
 * //        int []arr=new int[]{1,2,3,2,5,6};
 * //        while(flag){
 * //            flag=false;
 * //            for (int i=0,j=1;i< arr.length-1 && j< arr.length;i++,j++){
 * //                if (arr[i] > arr[j]){
 * //                  temp= arr[i];
 * //                  arr[i] = arr[j];
 * //                  arr[j] =temp;
 * //                  flag=true;
 * //                }
 * //            }
 * //        }
 * //        System.out.println(Arrays.toString(arr));
 *
 *
 *
 * for (int i=0,j=0;i< m && j< n;) {
 *             if (nums1[i] == 0) {
 *                 nums1[i] = nums2[j];
 *                 i++;
 *                 j++;
 *             } else {
 *                 i++;
 *             }
 *         }
 *             boolean flag=true;
 *     while(flag){
 *         flag = false;
 *         for (int x=0,y=1;x< nums1.length - 1 && y < nums1.length;x++,y++){
 *             if (nums1[x] > nums1[y]){
 *                 nums1[y] = nums1[y] + nums1[x];
 *                 nums1[x] = nums1[y] - nums1[x];
 *                 nums1[y] = nums1[y] - nums1[x];
 *                 flag=true;
 *             }
 *         }
 *     }
 *
 *      int leftPointer = nums1.length-1;
 *
 *         n--;
 *         m--;
 *         while(m >= 0 && n >= 0){
 *
 *             if(nums1[m] < nums2[n]){
 *                 nums1[leftPointer] = nums2[n--];
 *             }else{
 *                 nums1[leftPointer] = nums1[m--];
 *             }
 *             leftPointer--;
 *         }
 *         while (n >= 0){
 *             nums1[leftPointer] = nums2[n--];
 *             leftPointer--;
 *         }
 */