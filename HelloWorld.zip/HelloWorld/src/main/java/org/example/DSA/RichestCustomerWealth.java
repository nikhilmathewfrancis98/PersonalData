package org.example.DSA;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class RichestCustomerWealth {
    public static void main(String[] args) {
        int[][] matrix = {
                {2,8,7},{7,1,3},{1,9,5}
        };
        int wealth=0,sum=0;
        // Process each row differently using flatMap
//        int result = Stream.of(matrix)
//                .peek(x->System.out.println(x.length))
//                .flatMapToInt(row -> Arrays.stream(row).reduce(Integer::sum).stream())
//                .peek(System.out::println)
//                .max().getAsInt();
//        System.out.println(result);
        for (int[] ints : matrix) {
            for (int anInt : ints) {
                sum += anInt;
            }
            System.out.println(sum + " "+wealth);
            if (sum > wealth) {
                wealth = sum;
            }
            sum=0;
        }



        System.out.println(wealth);
    }

}
