package org.example.DSA.String;

class Solution14{
    public static String longestCommonPrefix(String[] strs) {
//        StringBuilder longestCommonPrefix=new StringBuilder(strs[0]);
//        StringBuilder newLongest;
//        for (int i = 1; i < strs.length; i++) {
//            newLongest = new StringBuilder();
//            for (int j = 0; j < strs[i].length() && j<longestCommonPrefix.length(); j++) {
//                if (longestCommonPrefix.charAt(j) == strs[i].charAt(j)){
//                    newLongest.append(strs[i].charAt(j));
//                }else {
//                    break;
//                }
//            }
//            longestCommonPrefix=newLongest;
//        }
//        return longestCommonPrefix.toString();
        if (strs == null || strs.length == 0) return "";
        String firstStr = strs[0];
        for (int i = 0; i < firstStr.length(); i++) {
            char cur = firstStr.charAt(i);
            System.out.println(cur);
            for (int j = 1; j < strs.length; j++){
                // for all other strings
                if (i == strs[j].length() || cur != strs[j].charAt(i)){
                    System.out.println(firstStr.substring(0, i));
                    return firstStr.substring(0, i);
                }
            }
        }
        return strs[0];
    }
}
public class LongestCommonPrefix {
    public static void main(String[] args) {
        String []str={"flower","flow","flight"};
        System.out.println(Solution14.longestCommonPrefix(str));
    }
}
