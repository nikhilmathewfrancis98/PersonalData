package org.example.DSA;

class SolutionSInsert{
    static int searchInsertK(int Arr[], int N, int k){
        int left = 0;
        int right = N;
        int index=0;
        while (left < right) {
            int mid = left + (right - left) / 2;

            if (k <= Arr[mid]) {
                right=mid;
                index=mid;
            } else {
                left=mid+1;
                index=mid+1;
            }

        }
        return index;

    }

}
public class SearchInsertPositionOfK {
    public static void main(String[] args) {
        int []arr =new int[]{1, 3, 5, 6};
        System.out.println(SolutionSInsert.searchInsertK(arr,arr.length,2));
    }
}
