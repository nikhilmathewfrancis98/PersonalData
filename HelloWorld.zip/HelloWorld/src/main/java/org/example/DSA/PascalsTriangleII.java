package org.example.DSA;

import java.util.ArrayList;
import java.util.List;

class Solution119 {
    public static List<Integer> getRow(int rowIndex) {
        List<List<Integer>> pascals=new ArrayList<>();

        for (int i=0;i<rowIndex + 1;i++){
            List<Integer> row = new ArrayList<>();
            for (int j=0;j <= i;j++){
                if (j == 0 || j==i){
                    row.add(1);
                }else{
                    row.add( pascals.get(i - 1).get(j) + pascals.get(i - 1).get(j - 1));

                }
            }
            pascals.add(row);

        }
        return pascals.get(rowIndex);
    }
}
public class PascalsTriangleII {
    public static void main(String[] args) {
        System.out.println(Solution119.getRow(3).toString());
    }
}
