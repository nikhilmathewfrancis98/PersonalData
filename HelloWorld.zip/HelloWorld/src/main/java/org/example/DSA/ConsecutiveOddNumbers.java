package org.example.DSA;
class SolutionConsecutive{
    public static boolean findConsecutive(int [] terms){
        int count=0;
        for (int i=0, j=0;j<terms.length;){
            if (terms[j] % 2 != 0){
                j++;
            }else {
                count = j-i;
                j+=1;
                i = j;
            }
            if( count == 3) return true;
        }
        System.out.println(count);
        return false;
    }
}
public class ConsecutiveOddNumbers {
    public static void main(String[] args) {
        int []arr = new int[]{1,2,34,3,4,5,7,23,12};
        int []arr1 = new int[]{2,6,4,1};
        System.out.println(SolutionConsecutive.findConsecutive(arr));
    }
}

/**
 *  Logic 1:
 *   int count=0;
 *         for (int j=0;j<terms.length;){
 *             if( count == 3) return true;
 *             if (terms[j] % 2 != 0){
 *                 j++;
 *                 count+=1;
 *             }else {
 *                 j++;
 *                 count=0;
 *             }
 *         }
 *
 *         return false;
 *
 *   Logic 2:
 *
 */