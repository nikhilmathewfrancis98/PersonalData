package org.example.DSA;

import java.util.*;
import java.util.stream.Collectors;

class Solution2SumMyWay{
    public static List<List<Integer>> get2Sum(int []nums){
        Set<List<Integer>> x=new HashSet<>();
          for (int i=1;i< nums.length;i++){
              for(int j=i;j<nums.length;j++){
                  if (nums[j] + nums[j-i] == 0){
                      List<Integer> g=new ArrayList<>(Arrays.asList(nums[j],nums[j-i]));
                      Collections.sort(g);
                    x.add(g);
                  }
              }
          }
          return x.stream().toList();
    }
}
public class TwoSumMyWay {
    public static void main(String[] args) {
        int[] arr=new int[]{-1,0,1,2,-1,-4}; //[[-1,-1,2],[-1,0,1]]
        int[] arr2=new int[]{0,1,1}; // []
        int [] arr3=new int[]{-2,0,1,1,2}; // [[0,0,0]]
           for (List<Integer> c:Solution2SumMyWay.get2Sum(arr3)){
            System.out.println(c.toString());
        }
    }
}
/**
 *  Set<List<Integer>> x=new HashSet<>();
 *         for (int i=1;i< nums.length;i++){
 *             for(int j=i;j<nums.length;j++){
 *                 if (nums[j] + nums[j-i] == 0){
 *                     List<Integer> g=new ArrayList<>(Arrays.asList(nums[j],nums[j-i]));
 *                     Collections.sort(g);
 *                   x.add(g);
 *                 }
 *             }
 *         }
 *         return x.stream().toList();
 */