package org.example.DSA;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

class SolutionPlusOne {
    public static int[] plusOne(int[] digits) {
//        List<Integer> res=new ArrayList<>();
//    long value=Long.parseLong( Arrays.stream(digits)
//            .mapToObj(String::valueOf)
//            .collect(Collectors.joining())) + 1;
//        System.out.println(value);

//        if (digits[digits.length - 1] < 9 ){
//            digits[digits.length - 1] = digits[digits.length - 1] + 1;
//            return digits;
//        }else{
//            BigInteger bigInt = new BigInteger(Arrays.stream(digits)
//                    .mapToObj(String::valueOf)
//                    .collect(Collectors.joining()));
//
//            // Add 1 to the BigInteger
//            bigInt = bigInt.add(BigInteger.ONE);
//          return   Arrays.stream(bigInt.toString().split(""))
//                    .mapToInt(Integer::parseInt)
//                    .toArray();
//            return Arrays.stream(String.valueOf(Long.parseLong( Arrays.stream(digits)
//                            .mapToObj(String::valueOf)
//                            .collect(Collectors.joining())) + 1).split(""))
//                    .mapToInt(Integer::valueOf)
//                    .toArray();
//        }



//        for (int i=0;i< digits.length;i++){
//            if (i == digits.length-1 && digits[i] == 9){
//                res.add(1);
//                res.add(0);
//            }else if(i == digits.length-1 && digits[i] < 9){
//                res.add(digits[i] + 1);
//            }else {
//                res.add(digits[i]);
//            }
//        }
//
        // Convert the passed digits array into a single integer using the for loop approach
//        Note this won't work for the larger numbers
        long result=0;
        long offset=1;
        for (int i= digits.length - 1;i>=0;i--){
            System.out.println(result);
            result+=digits[i]*offset;
            offset*=10;
        }
        System.out.println(result);
        int n = digits.length;
        for (int i=n-1;i>=0;i--){
            if (digits[i]<9){
                digits[i]++;
//                System.out.println("Inside the if"+Arrays.toString(digits));
                return digits;
            }
            digits[i]=0;
//            System.out.println(Arrays.toString(digits));
        }
        int []newarr = new int[n+1];
        newarr[0]=1;
        return newarr;
    }
}
public class PlusOne {
    public static void main(String[] args) {
//        {9,8,7,6,5,4,3,2,1,0}
//        {5,2,2,6,5,7,1,9,0,3,8,6,8,6,5,2,1,8,7,9,8,3,8,4,7,2,5,8,9}
        int[] arr=new int[]{9,8,7,6,5,4,3,2,1,0};
        System.out.println(Arrays.toString(SolutionPlusOne.plusOne(arr)));
    }
}
