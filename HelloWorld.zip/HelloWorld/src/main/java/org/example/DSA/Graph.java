package org.example.DSA;
import java.util.ArrayList;
import java.util.List;

class Gra {
    private final List<List<Integer>> adjacencyList;

    public Gra(int[][] matrix) {
        adjacencyList = new ArrayList<>();
        for (int i = 0; i < matrix.length; i++) {
            List<Integer> neighbors = new ArrayList<>();
            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] == 1) {
                    neighbors.add(j);
                }
            }
            adjacencyList.add(neighbors);
        }
    }

    public List<List<Integer>> getAdjacencyList() {
        return adjacencyList;
    }
}
public class Graph {
    public static void main(String[] args) {
        int[][] matrix = {
                {0, 1, 1},
                {1, 0, 1},
                {1, 1, 0}
        };
        Gra x=new Gra(matrix);
        x.getAdjacencyList().forEach(System.out::println);
    }
}
