package org.example.DSA;

import java.util.Arrays;

class SolutionFindLargest{
    public static int  find(int[] arr,int target){
        int Firstlargest=Integer.MIN_VALUE;
        int SecondNum=Integer.MIN_VALUE;
        for (int x:arr){
            if (x > Firstlargest){

                SecondNum = Firstlargest;
                Firstlargest = x;
            } else if (x>SecondNum && x!=Firstlargest) {
                SecondNum = x;
            }
        }
//        System.out.println(Arrays.toString(arr));
        return SecondNum;
    }
}
public class FindSecondLargestNotSorted {
    public static void main(String[] args) {
        int[] arr=new int[]{3,7,9,2,8,15};
        System.out.println(SolutionFindLargest.find(arr,2));
    }
}
