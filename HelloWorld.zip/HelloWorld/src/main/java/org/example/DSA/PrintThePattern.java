package org.example.DSA;

/**
 *    n = 4
 *    A
 *    b C
 *    D e F
 *    g H i J
 */
public class PrintThePattern {
    public static void main(String[] args) {
        int n=4;
        char x='A';
        for (int i = 0;i < n;i++) {
            for (int j = 0; j <= i; j++) {
                if ((i + j) % 2 ==  0) {
                    System.out.print(x+" ");
                } else {
                    System.out.print(String.valueOf(x).toLowerCase()+" ");
                }
                x+=1;
            }
            System.out.println();
        }
    }
}
