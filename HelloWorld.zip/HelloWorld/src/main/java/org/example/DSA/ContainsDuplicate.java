package org.example.DSA;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

class Solution217 {
    public static boolean containsDuplicate(int[] nums) {
//        Set<Integer> x=new HashSet<>();
//        for (int c:nums){
//            if (!x.add(c)){
//                return true;
//            }
//        }
//        return false; Logic 1

        for (int i=0;i< nums.length - 1;i++){
            for (int j=i+1;j< nums.length;j++){
                if (nums[i] == nums[j]) return true;
            }
        }

        return false;
    }
}
public class ContainsDuplicate {
    public static void main(String[] args) {
        int []arr=new int[]{1,2,3,1};
        int []arr2=new int[]{1,2,3,4};
        System.out.println(Solution217.containsDuplicate(arr2));
    }
}
/**
 *   for(int i = 1; i < nums.length; i++){
 *             if(nums[i - 1] == nums[i])
 *                 return true;
 *             else if (nums[i] < nums[i - 1]){
 *                 int temp = nums[i - 1];
 *                 for(int j = i - 2; j >= 0; j--){
 *                     if(nums[i] == nums[j])
 *                         return true;
 *                 }
 *                 nums[i - 1] = nums[i];
 *                 nums[i] = temp;
 *             }
 *         }
 *         return false;
 */