package org.example.DSA;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Palindrome {
    public static void main(String[] args) {

        ArrayList<String> x= new ArrayList<>(Arrays.asList("Name1","Name2","Name3"));
      Optional<String> o=  x.stream().filter(c-> c.indexOf("2") !=0)
              .findFirst();
        System.out.println(o.get());

        int pal=121;
        int ori=pal;
        int reversed=0,val=0;
        while(pal > 0){
             val = pal % 10;
                     reversed = reversed * 10 + val;
                            pal=pal/10;

        }
        if (reversed == ori){
            System.out.println("palindrome");
        }else {
            System.out.println("Not Palindrome");
        }

    }
}
