package org.example.DSA;

import java.util.*;
import java.util.stream.Collectors;

class SolutionMeetings {
    // Function to find the maximum number of meetings that can be performed in a meeting room.
    public  int maxMeetings(int start[], int end[]) {
        int max=1,currentEndTime;
        int[][] meetingRoom=new int[start.length][2];
        for (int i=0;i<meetingRoom.length;i++){
            meetingRoom[i][0]=start[i];
            meetingRoom[i][1]=end[i];
        }
        Arrays.sort(meetingRoom,Comparator.comparing(a->a[1]));
        currentEndTime = meetingRoom[0][1];
        for (int i=1;i<meetingRoom.length;i++){
            if (meetingRoom[i][0] > currentEndTime){
                currentEndTime = meetingRoom[i][1];
                max++;
            }
        }

        return max;
    }
}
public class NMeetingsInOneRoom {
    public static void main(String[] args) {
//        int[] start={1, 3, 0, 5, 8, 5,6};
//        int[] end=  {2, 4, 6, 7, 9, 9,7};
//        int[] start={1, 3, 8, 6};
//        int[] end=  {2, 4, 9, 7};
        int[] start={3, 2,5};
        int[] end=  {4, 6,8};
        System.out.println(new SolutionMeetings().maxMeetings(start,end));
    }
}
/**
 *    int n = start.length;
 *
 *         // Create a 2D array to store the meetings as (start, end) pairs
 *         int[][] meetings = new int[n][2];
 *         for (int i = 0; i < n; i++) {
 *             meetings[i][0] = start[i];  // start time
 *             meetings[i][1] = end[i];    // end time
 *         }
 *
 *         // Sort the meetings by end time
 *         Arrays.sort(meetings, Comparator.comparingInt(a -> a[1]));
 *
 *         // Initialize variables for counting meetings and tracking the last end time
 *         int count = 1;  // We can always select the first meeting after sorting
 *         int last_end_time = meetings[0][1];
 *
 *         // Iterate through the remaining meetings
 *         for (int i = 1; i < n; i++) {
 *             // If the start time of the current meeting is greater than or equal to the last end time
 *             if (meetings[i][0] > last_end_time) {
 *                 // Select this meeting and update the last end time
 *                 count++;
 *                 last_end_time = meetings[i][1];
 *             }
 *         }
 *
 *         return count;
 *
 *         Logic 2 But not working in the GFG site
 *
 *          Map<Integer, Integer> map = new HashMap<>();
 *         int max=0,currEndTime=0;
 *         for (int i = 0; i < start.length; i++) {
 *             map.put(start[i], end[i]);
 *         }
 *         Map<Integer, Integer> sortedByValue = map.entrySet()
 *                 .stream()
 *                 .sorted(Map.Entry.comparingByValue())
 *                 .collect(Collectors.toMap(
 *                         Map.Entry::getKey,
 *                         Map.Entry::getValue,
 *                         (e1, e2) -> e1, // merge function to handle duplicate keys
 *                         LinkedHashMap::new));
 *         for (Map.Entry<Integer, Integer> entry : sortedByValue.entrySet()) {
 *             if (entry.getKey() > currEndTime) {
 *                 currEndTime = entry.getValue();
 *                 max++;
 *             }
 *         }
 *         return max;
 */