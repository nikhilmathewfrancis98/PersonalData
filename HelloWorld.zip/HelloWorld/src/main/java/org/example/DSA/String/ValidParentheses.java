package org.example.DSA.String;

import java.util.*;

class Solution20{
    public static boolean isValid(String s) {
        Stack<String> resultStack=new Stack<>();
//        Map<String, String> x=Map.of("]","[","}","{",")","(");
        Map<String,String> hash=new HashMap<>();
        hash.put("]","[");
        hash.put("}","{");
        hash.put(")","(");
        for (String i:s.split("")){
            if (!resultStack.isEmpty() && Objects.equals(resultStack.peek(), hash.get(i))) {
                resultStack.pop();
            }else if (resultStack.isEmpty()){
                resultStack.push(i);
            }else {
                resultStack.push(i);
            }


        }

        return resultStack.isEmpty();

    }
}
public class ValidParentheses {
    public static void main(String[] args) {
        String s="(){}}{";
        String s2="[)";
        System.out.println(Solution20.isValid(s2));
    }
}
/**
 *  Logic Tc 3ms
 *
 *   int sLength = s.length();
 *
 *         if( sLength % 2 != 0) return false;
 *
 *         Deque<Character> stack = new ArrayDeque<Character> ();
 *
 *         Map<Character, Character> pairings = Map.of(')', '(', ']', '[', '}', '{'); //Need to test this
 *
 *
 *         for (char currentChar : s.toCharArray()) {
 *             if ( pairings.containsValue(currentChar)) { // Check by value not by key
 *                 stack.push(currentChar);
 *             } else {
 *                 if(stack.isEmpty() || stack.pop() != pairings.get(currentChar)) { //Get value by key
 *                     return false;
 *                 }
 *             }
 *         }
 *         return stack.isEmpty();
 *
 */