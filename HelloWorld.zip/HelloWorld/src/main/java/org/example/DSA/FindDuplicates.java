package org.example.DSA;

import java.util.*;

public class FindDuplicates {
    public static void main(String[] args) {
        List<Integer> arr=new ArrayList<>(Arrays.asList(2, 17, 5, 20, 17, 30, 4, 23, 59, 23));
        Set<Integer> s1 =new HashSet<>();
        List<Integer> result=new ArrayList<>();

        for (int i:arr)
            if (!s1.add(i)){
                result.add(i);
            }
        System.out.println(result);
    }
}
