package org.example.DSA;

class Solution268 {
    public static int missingNumber(int[] nums) {
        int sum=nums.length*(nums.length + 1)/2;
//        for(int i=0;i<=nums.length;i++){
//            sum+=i;
//        }
        for (int num : nums) {
            sum -= num;
        }
        System.out.println(sum);
        return 4;
    }
}
public class MissingNumber {
    public static void main(String[] args) {
        int []arr=new int[]{9,6,4,2,3,5,7,0,1};
        System.out.println(Solution268.missingNumber(arr));
    }
}
