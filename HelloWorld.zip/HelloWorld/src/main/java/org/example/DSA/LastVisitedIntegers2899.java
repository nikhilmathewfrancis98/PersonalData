package org.example.DSA;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Eg 1: Input: nums = [1,2,-1,-1,-1]
 *       Output: [2,1,-1]
 *
 * Eg 2: Input: nums = [1,-1,2,-1,-1]
 *       Output: [1,2,1]
 *
 */
class Solution1 {
    public List<Integer> lastVisitedIntegers(int[] nums) {
        // Write your code here
        List<Integer> ans=new ArrayList<>();
        List<Integer> seen=new ArrayList<>();
        int k=0;
        for (int i=0;i< nums.length;i++){
            if (nums[i] > 0){
                seen.add(0,nums[i]);
            }else if(nums[i] == -1){
                if(i != 0 && nums[i - 1] == -1){
                    k+=1;
                    if (seen.isEmpty()){
                        ans.add(nums[i]);
                    } else if (k > seen.size()) {
                        ans.add(nums[i]);
                    }else {
                        ans.add(seen.get(k - 1));
                    }
                }else if (i == 0){
                    k+=1;
                    if (seen.isEmpty()){
                        ans.add(nums[i]);
                    }else if (k > seen.size()) {
                        ans.add(nums[i]);
                    }else {
                        ans.add(seen.get(k - 1));
                    }
                }else if(i != 0 && nums[i - 1] != -1){
                    k=0;
                    ++k;
                    if (seen.isEmpty()){
                        ans.add(nums[i]);
                    }else if (k > seen.size()) {
                        ans.add(nums[i]);
                    }else {
                        ans.add(seen.get(k - 1));
                    }
                }

            } // elseif main end


        } // End Of For Loop
        System.out.println(k+"  "+ Arrays.toString(seen.toArray()));
        return ans;
    }
}
public class LastVisitedIntegers2899 {
    public static void main(String[] args) {
        int [] arr=new int[]{1,2,-1,-1,-1};
        int[] arr1=new int[]{1,-1,2,-1,-1};
        int [] arr2=new int[]{-1,-1,-1,27};
       Solution1 x= new Solution1();
        System.out.println(x.lastVisitedIntegers(arr).toString());
    }
}

/**
 *  class Solution {
 *     public List<Integer> lastVisitedIntegers(int[] nums) {
 *         List<Integer> seen = new ArrayList<>();
 *         List<Integer> ans = new ArrayList<>();
 *         int k = 0;
 *         for(int i= 0;i<nums.length;i++){
 *             if(nums[i] > 0){
 *                 seen.add(nums[i]);
 *                 k = 0;
 *             }
 *             else if(nums[i] == -1){
 *                 k++;
 *                 if(k<=seen.size()) ans.add(seen.get(seen.size() - k));
 *                 else if(k>seen.size()) ans.add(-1);
 *             }
 *         }
 *         return ans;
 *     }
 * }
 */