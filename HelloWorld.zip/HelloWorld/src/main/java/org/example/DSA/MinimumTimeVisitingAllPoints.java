package org.example.DSA;


class Solution {

    public int minTimeToVisitAllPoints(int[][] points) {
        int count=0;
         int x=0,y=0,xNext=0,yNext=0;
        for (int i=0;i<points.length - 1;i++) {
            x = points[i][0];
            y = points[i][1];
            xNext=points[i + 1][0];
            yNext=points[i + 1][1];
            if (x <= xNext){
                count += up(x,y,xNext,yNext,count);
            }else {
                count +=  down(x,y,xNext,yNext,count=0);
            }
        }
        System.out.println(count);
        return count;
    }

    public static int up(int x,int y,int xNext,int yNext,int count){
        int cnt=0;
        if (x == xNext && y == yNext){
            return count;
        }
        if (x + 1 <= xNext && y + 1 <= yNext){
            cnt = up(x + 1,y + 1,xNext,yNext,count+=1);
        }else if(x + 1 <= xNext && y + 1 >= yNext){
            cnt=  up(x + 1,y,xNext,yNext,count+=1);
        } else if (x + 1 >= xNext && y + 1 <= yNext) {
            cnt=  up(x,y + 1,xNext,yNext,count+=1);
        }

        return cnt;
    }
    public static  int down(int x,int y,int xNext,int yNext,int count){
        int cnt=0;
        if (x == xNext && y == yNext){
            return count;
        }
        if (x - 1 >= xNext && y - 1 >= yNext){
            cnt= down(x - 1,y - 1,xNext,yNext,count+=1);
        }else if(x - 1 >= xNext && y - 1 <= yNext){
            cnt= down(x - 1,y,xNext,yNext,count+=1);
        } else if (x - 1 <= xNext && y - 1 >= yNext) {
            cnt= down(x,y - 1,xNext,yNext,count+=1);
        }

        return cnt;
    }


/**
 * Solution 2 is find the distance between each point using the
 * Manhattan distance between consecutive points
 */
public int manhattanDistance(int[][] mat){
    int count=0;
    for (int i=0;i< mat.length - 1;i++) {
        int x = mat[i][0];
        int y=mat[i][1];
        int XNext=mat[i+1][0];
        int YNext=mat[i+1][1];
        count+=Math.max(Math.abs(XNext - x),Math.abs(YNext - y));
    }
    return count;
}

}
public class MinimumTimeVisitingAllPoints {
    public static void main(String[] args) {
        Solution s=new Solution();
        /**
         *   {1, 1},
         *   {3,4},
         *   {-1,0}
         *
         *  {3,2},
         *  {-2,2},
         *
         *  {559,511},{932,618},{-623,-443},{431,91},{838,-127},{773,-917},
         *  {-500,-910},{830,-417},{-870,73},{-864,-600},{450,535},{-479,-370},
         *  {856,573},{-549,369},{529,-462},{-839,-856},{-515,-447},{652,197},
         *  {-83,345},{-69,423},{310,-737},{78,-201},{443,958},{-311,988},{-477,30},
         *  {-376,-153},{-272,451},{322,-125},{-114,-214},{495,33},{371,-533},{-393,-224},
         *  {-405,-633},{-693,297},{504,210},{-427,-231},{315,27},{991,322},{811,-746},{252,373},
         *  {-737,-867},{-137,130},{507,380},{100,-638},{-296,700},{341,671},{-944,982},
         *  {937,-440},{40,-929},{-334,60},{-722,-92},{-35,-852},{25,-495},{185,671},{149,-452}
         *
         */
        int[][] matrix = {
                {559,511},{932,618},{-623,-443},{431,91},{838,-127},{773,-917},
                {-500,-910},{830,-417},{-870,73},{-864,-600},{450,535},{-479,-370},
          {856,573},{-549,369},{529,-462},{-839,-856},{-515,-447},{652,197},
           {-83,345},{-69,423},{310,-737},{78,-201},{443,958},{-311,988},{-477,30},
           {-376,-153},{-272,451},{322,-125},{-114,-214},{495,33},{371,-533},{-393,-224},
           {-405,-633},{-693,297},{504,210},{-427,-231},{315,27},{991,322},{811,-746},{252,373},
           {-737,-867},{-137,130},{507,380},{100,-638},{-296,700},{341,671},{-944,982},
           {937,-440},{40,-929},{-334,60},{-722,-92},{-35,-852},{25,-495},{185,671},{149,-452}
        };
        System.out.println(s.manhattanDistance(matrix));
    }
}
