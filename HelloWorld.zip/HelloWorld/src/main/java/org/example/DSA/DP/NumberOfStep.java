package org.example.DSA.DP;

import java.util.Arrays;

/**
 * This is the hacker earth question
 *  Number Of steps
 */
class SolutionNoOFSteps{
    public static int countTheSteps(int[] a, int[] b){
        int steps = 0;
        int min = Arrays.stream(a).min().orElse(Integer.MAX_VALUE);

        for (int i = 0; i < a.length; i++) {
            while (a[i] > min) {
                a[i] -= b[i];
                steps++;
            }
            if (a[i] < min) {
                min = a[i];
                i = -1; // Restart the loop to adjust all elements to the new minimum
            }
        }

        System.out.println(Arrays.toString(a));
        return steps;
    }
}
public class NumberOfStep {
    public static void main(String[] args) {
        int[] a={5,7,10,5,15};
        int[] b={2,2,1,3,5};
        System.out.println(SolutionNoOFSteps.countTheSteps(a,b));
    }
}

/**
 * int steps = 0;
 *         int min = Arrays.stream(a).min().orElse(Integer.MAX_VALUE);
 *
 *         for (int i = 0; i < a.length; i++) {
 *             while (a[i] > min) {
 *                 a[i] -= b[i];
 *                 steps++;
 *             }
 *             if (a[i] < min) {
 *                 min = a[i];
 *                 i = -1; // Restart the loop to adjust all elements to the new minimum
 *             }
 *         }
 *
 *         System.out.println(Arrays.toString(a));
 *         return steps;
 *
 *
 *
 *       int steps=0;
 *             boolean flag=true;
 *             int min;
 *             while (flag){
 *                 flag=false;
 *                  min=Integer.MAX_VALUE;
 *                 for (int i=0; i<a.length;i++){
 *                     if (min > a[i]) min=a[i];
 *                     if(a[i] <= min){continue;}
 *                     else{
 *                         a[i] = a[i] - b[i];steps+=1;flag=true;
 *                     }
 *                 }
 *                 System.out.println("Step: "+steps+" --> "+Arrays.toString(a)+" min: "+min);
 *
 *             }
 *
 *
 *         return steps;
 */