package org.example.DSA;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Solution5 {
    public int searchInsert(int[] nums, int target) {
//        int mid = nums.length / 2;
        int result=0;
//        int i = 0, j = 0;
//        if (target >= nums[mid]) {
//            i = mid;
//            j = nums.length;
//        } else {
//            i = 0;
//            j = mid;
//        }
//        while (i < j) {
//            if(target > nums[j - 1]){
//                i= nums.length;
//                break;
//            }
//            if (nums[i] == target) {
//                break;
//
//            } else if (nums[i] <= target && nums[i + 1] == target + 1) {
//                ++i;
//                break;
//            }
//            i++;
//
//        } // While loop closing
//        Integer[] integerArray = Arrays.stream(nums).boxed().toArray(Integer[]::new);
//        List<Integer> x = new ArrayList<>(Arrays.asList(integerArray));
//        if (x.contains(target)){
//            result= x.indexOf(target);
//        }else if (target > 0 &&  x.contains(target - 1)){
//            result= x.indexOf(target - 1) + 1;
//        }else if(target <= nums[0]){
//            result=  0;
//        }
        int i=0;
        while(i < nums.length) {
            if (target == nums[i]) {
                result = i;
                break;
            } else if (target < nums[i]) {
                System.out.println("Inside else if 1");
                result = i;
                break;
            } else if (target > nums[i]) {
                System.out.println("Inside else if 2");
                result = i + 1;
            }
            i++;
        }
            return result;
    } // method closing
}//Class closing
public class SearchInsertPosition {
    public static void main(String[] args) {
        Solution5 s=new Solution5();
        int arr1[] =new int[]{1,3,5,6}; // target = 5  o/p = 2
        int arr2[]=new int[]{3,6,7,8,10};
         // target = 2  o/p = 1
      // target = 7   o/p = 4

        System.out.println(s.searchInsert(arr1,7));
    }
}
