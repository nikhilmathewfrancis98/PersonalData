package org.example.DSA.Arrays;

class Solution414 {
    public static int thirdMax(int[] nums) {
        int first = Integer.MIN_VALUE,second = Integer.MIN_VALUE,third = Integer.MIN_VALUE;
        for (int x:nums){
            if (x > first) {
                if (first >= second) {
                    if (second >= third) {
                        third = second;
                    }
                    second = first;
                }
                first = x;
            } else if (x>second && x!=second) {
                if (second >= third) {
                    third = second;
                }
                second = x;
            } else if (x>=third && x!=second && x!=first) {
                third = x;

            }
            System.out.println("first: "+first+" second: "+second+" third: "+third);

        }
        return (nums.length >= 3)?third:first;
    }
}
public class ThirdMaximumNumber {

    public static void main(String[] args) {
    int [] arr =new int[]{2,2,3,1};
        System.out.println(Solution414.thirdMax(arr));
        System.out.println(Integer.MIN_VALUE);
//        -2147483648
    }
}
