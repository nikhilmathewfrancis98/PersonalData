package org.example.DSA;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class LargestTriangleArea {
    public static void main(String[] args) {
        int[][] points = {{0, 0}, {0, 1}, {1, 0}, {0, 2}, {2, 0}};
        int[][] points2 = {{4, 2}, {6, 5}, {2, 1}, {9, 2}, {8, 1},{5,4},{7,9}};

        System.out.printf("%.5f\n", largestTriangleArea(points2));
    }

    public static double largestTriangleArea(int[][] points) {
        int n = points.length;
        double maxArea = 0.0;

        // Iterate through all combinations of three points
        for (int i = 0; i < n - 2; i++) {
            for (int j = i + 1; j < n - 1; j++) {
                for (int k = j + 1; k < n; k++) {
                    System.out.println(Arrays.toString(points[i]) +" "+ Arrays.toString(points[j]) +" "+ Arrays.toString(points[k]));
                    double area = calculateArea(points[i], points[j], points[k]);
                    maxArea = Math.max(maxArea, area);
                }
            }
        }

        return maxArea;
    }

    // Calculate the area of a triangle given its vertices using the Shoelace formula
    private static double calculateArea(int[] p1, int[] p2, int[] p3) {
        return 0.5 * Math.abs(
                p1[0] * (p2[1] - p3[1]) +
                        p2[0] * (p3[1] - p1[1]) +
                        p3[0] * (p1[1] - p2[1])
        );
    }
}