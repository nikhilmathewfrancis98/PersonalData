package org.example.DSA;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class NinjaMeetingPoint {
    public static void main(String[] args) {
        /**
         * {1 ,0 ,0},
         * {1 ,0 ,1},
         * {0, 1, 0},  --> 21
         * {1, 0, 0},
         * {0, 1, 0},
         * {0, 1, 1},
         * {0, 1, 0}
         *
         * {0, 1, 1, 1, 0 ,0},
         * {1, 1, 1, 1 ,0 ,0},
         * {1, 0, 0, 0, 1, 1},  --> 46
         * {0, 1, 0, 1, 0, 0},
         * {1, 0, 0, 1, 1, 1},
         * {0, 0, 1, 0, 0, 0}
         *
         * {1, 0, 0},
         * {0 ,0 ,0},   --> 4
         * {0 ,0 ,1}
         *
         * {1 ,1 ,0},
         * {0 ,1 ,0},   --> 6
         * {0 ,1 ,1}
         *
         * {1 ,0 ,1 ,0 ,1},
         * {0 ,1 ,0 ,1 ,0},
         * {1 ,0 ,1 ,0 ,1},  --> 32
         * {0 ,1 ,0 ,1 ,0},
         * {1 ,0 ,1 ,0 ,1}
         *
         * {1 ,0 ,1},
         * {1 ,1 ,0},
         * {0, 0, 0},  --> 7
         * {1 ,0 ,0}
         */
        int[][] matrix = {
                {0, 1, 1, 1, 0 ,0},
                {1, 1, 1, 1 ,0 ,0},
                {1, 0, 0, 0, 1, 1},
                {0, 1, 0, 1, 0, 0},
                {1, 0, 0, 1, 1, 1},
                {0, 0, 1, 0, 0, 0}
        };
            // Find the optimal meeting point and print the result
            System.out.println(findMinDistance(matrix, matrix.length, matrix[0].length));
//            for (int i: matrix[0].)
//                System.out.println(i);
    }

    private static int findMinDistance(int[][] mat, int N, int M) {
        List<Integer> xCoords = new ArrayList<>();
        List<Integer> yCoords = new ArrayList<>();

        // Extract the coordinates of all homes
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < M; j++) {
                if (mat[i][j] == 1) {
                    xCoords.add(i);
                    yCoords.add(j);
                }
            }
        }

        // Find the median of the x-coordinates and y-coordinates
        int medianX = findMedian(xCoords);
        int medianY = findMedian(yCoords);
        System.out.println(medianX+" "+medianY);
        // Calculate the total Manhattan distance to the meeting point (medianX, medianY)
        int totalDistance = 0;
        for (int i = 0; i < xCoords.size(); i++) {
            totalDistance += Math.abs(xCoords.get(i) - medianX) + Math.abs(yCoords.get(i) - medianY);
        }

        return totalDistance;
    }

    private static int findMedian(List<Integer> coords) {
//        Collections.sort(coords);
        int size = coords.size();
        if (size % 2 == 0) {
            System.out.println("Inside"+ (size / 2 - 1)+"   "+size);
            return coords.get(size / 2 - 1);
        } else {
            System.out.println("Inside"+ (size / 2 )+"   "+size);
            return coords.get(size / 2);
        }
    }
}