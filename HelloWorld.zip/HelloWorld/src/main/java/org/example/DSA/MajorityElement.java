package org.example.DSA;

import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;

class Solution169 {
    public static int majorityElement(int[] nums) {
//        HashMap<Integer,Integer> hash=new HashMap<>();
        int max=0,val = nums.length / 2;
       Map.Entry<Integer,Long>x= Arrays.stream(nums)
                .boxed()
                .collect(Collectors.groupingBy(a->a,Collectors.counting()))
                .entrySet()
                .stream()
                .sorted(Map.Entry.<Integer,Long>comparingByValue().reversed())
                .findFirst().get();
//                .forEach(x-> System.out.println(x.getKey()+" --> "+ x.getValue()));
//                .collect(Collectors.toMap(Map.Entry::getKey,Map.Entry::getValue));
//        for (Map.Entry z : x.entrySet())
//            System.out.println(z.getValue());

//            for (Integer number : nums) {
//                hash.put(number, hash.getOrDefault(number, 0) + 1);
//                if (hash.get(number) > val){
//                    max=number;
//                }
//        }


        return (Math.toIntExact(x.getValue()) > val)?Math.toIntExact(x.getValue()):0;
    }
}
public class MajorityElement {
    public static void main(String[] args) {
        int[] array;
        array=new int[]{1,2,3,4,5};
        String[] str={"N","M","F"};
        int []arr=new int[]{2,2,1,1,1,2,2};
        int []arr1=new int[]{3,2,3};
        System.out.println(Solution169.majorityElement(arr));
        Supplier<Integer> s= () -> 0;
    }
}
//  elementNumber.put(nums[i], elementNumber.containsKey(nums[i]) ? elementNumber.get(nums[i])+1 : 1);

/**
 *  6ms code
 *  class Solution {
 *     public static int majorityElement(int[] nums) {
 *         return helper(nums,0,nums[0]);
 *     }static int helper(int[] nums, int si, int ref){
 *         int c=0;
 *         for(int i=si;i<nums.length;i++){
 *             if(nums[i]==ref)
 *                 c++;
 *             else
 *                 c--;
 *             if(c==-1)
 *                 return helper(nums,i,nums[i]);
 *         }return ref;
 */