package org.example.DSA;

import java.util.ArrayList;
import java.util.List;

public class SumBetweenZeros {
    public static List<Integer> findSum(int[] arr){
        List<Integer> sums=new ArrayList<>();
        int sum=0;
        for (int i=0,j=1;i < j && j < arr.length;){
            if (arr[j] == 0){
                if (sum != 0){
                    sums.add(sum);
                }

                i=j;
                j++;
                sum=0;
            }
           else if(arr[i] == 0){
                sum+=arr[j++];
            }else {
                i++;
                j++;
            }
        } // end of for loop

        return sums;
    }
    public static void main(String[] args) {
        int []arr1=new int[]{0,1,0,3,0,2,2,0}; // [1,3,4]
        int []arr2=new int[]{0,3,1,0,4,5,2,0}; // [4,11]
        int []arr3=new int[]{3,2,0,1,0,3,8,0}; // [1,11]
        System.out.println(findSum(arr2).toString());
    }
}
