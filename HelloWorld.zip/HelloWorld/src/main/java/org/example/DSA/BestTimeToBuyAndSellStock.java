package org.example.DSA;
class Solution121 {
    public static int maxProfit(int[] prices) {
        int min = prices[0]; //initially taking first element as min
        int max = 0; //max profit is 0 initially
        System.out.println("Initially min: "+min+" and max:"+max);
        for (int price : prices) {
            if (price < min){ //checking if there is any prices less than min
                min = price;
            System.out.println(price+" min: "+min);}
            if (max < price - min){ //similarly checking max
                System.out.println(price+" max: "+max+" "+(price - min));
                max = price - min;}
        }
        return max;

    }
}
public class BestTimeToBuyAndSellStock {
    public static void main(String[] args) {
        int []arr=new int[]{7,1,5,3,6,4};
        int []arr1=new int[]{7,6,4,3,1};
        int []arr2=new int[]{1,2};
        System.out.println(Solution121.maxProfit(arr));
    }
}
/**
 *  Logic Mine
 *   int Buy;
 *         int sell;
 *         int high=0;
 *         int profit=0;
 *         for (int i = 0,j=i+1;j < prices.length;) {
 *             if (prices[i] < prices[j]) {
 *                 Buy = i;
 *                 if (prices[j] > high) {
 *                     high = prices[j];
 *                     sell = j;
 *                     profit = Math.max(prices[sell] - prices[Buy], profit);
 *                     j++;
 *
 *             } else if (high != 0) {
 *                 sell = j;
 *                     profit = Math.max(prices[sell] - prices[Buy], profit);
 *                 j++;
 *             } else {
 *                 sell = j;
 *                     profit = Math.max(prices[sell] - prices[Buy], profit);
 *                 i = j;
 *                 j++;
 *              }
 *         }else {
 *             i=j;
 *             j++;
 *         }
 *     }
 *         return profit;
 */