package org.example.DSA;

import java.awt.image.AreaAveragingScaleFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class Solution118 {
    public static List<List<Integer>> generate(int numRows) {
        List<List<Integer>> pascals=new ArrayList<>();

        for (int i=0;i<numRows;i++){
            List<Integer> row = new ArrayList<>();
            for (int j=0;j <= i;j++){
                if (j == 0 || j==i){
                    row.add(1);
                }else {
                    row.add( pascals.get(i - 1).get(j) + pascals.get(i - 1).get(j - 1));
                }

            }
            pascals.add(row);
        }// End of outer for loop
        for (List<Integer> j: pascals)
            System.out.println(j.toString());
        return pascals;
    }
}
public class PascalsTriangle {
    public static void main(String[] args) {
        Solution118.generate(6);
    }
}

/**
 *  Using the Array so the remaining values will become the Zeros
 *
 *   int[][] pascals=new int[numRows][numRows];
 *
 *         for (int i=0;i<numRows;i++){
 *             for (int j=0;j <= i;j++){
 *                 if (j == 0 || j==i){
 *                    pascals[i][j]=1;
 *                 }else {
 *                     pascals[i][j] = pascals[i - 1][j] + pascals[i-1][j-1];
 *                 }
 *             }
 *         }// End of outer for loop
 *         for (int[] x: pascals)
 *             System.out.println(Arrays.toString(x));
 */