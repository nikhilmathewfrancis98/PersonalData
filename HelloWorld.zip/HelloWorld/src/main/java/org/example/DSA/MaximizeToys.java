package org.example.DSA;

import java.util.Arrays;

class SolutionMaximizeToys{
    public  static int toyCount(int N, int K, int arr[]){
        int maxItems=0;
        Arrays.sort(arr);

        for (int j=0;j < arr.length;j++){
            if (arr[j] > K) break;
            K-=arr[j];
            maxItems+=1;
        }
        return maxItems;
    }
}
public class MaximizeToys {
    public static void main(String[] args) {
        int []arr=new int[]{1, 12, 5, 111, 200, 1000, 10};
        int[] arr2=new int[]{20 ,30, 50};
        System.out.println(SolutionMaximizeToys.toyCount(arr.length,100,arr2));
    }
}
