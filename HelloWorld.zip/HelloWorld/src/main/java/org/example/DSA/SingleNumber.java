package org.example.DSA;

import java.util.*;
import java.util.stream.Collectors;

class Solution136 {
    public static int singleNumber(int[] nums) {
        TreeSet<Integer> uniqueValues = new TreeSet<>();
        for (int num : nums) {
            if (!uniqueValues.remove(num)) {
                uniqueValues.add(num);
            }
        }
      return uniqueValues.first();
    }
}
public class SingleNumber {
    public static void main(String[] args) {
        int []arr=new int[]{4,1,2,1,2};
        System.out.println(Solution136.singleNumber(arr));
    }
}

/**
 *   Optional<Map.Entry<Integer, Long>> val=  Arrays.stream(nums)
 *                 .boxed()
 *                 .collect(Collectors.groupingBy(integer -> integer,Collectors.counting()))
 *                 .entrySet()
 *                 .stream()
 *                 .filter(x->x.getValue() == 1)
 *                 .findFirst();
 *     val.map(integerLongEntry -> Math.toIntExact(integerLongEntry.getValue())).orElse(0);
 *         return val.get().getKey();
 */