package org.example.GenericsInJava;
class Solution<T extends String>{
    private T fieldName;

    public T getFieldName() {
        return fieldName;
    }

    public void setFieldName(T fieldName) {
        this.fieldName = fieldName;
    }
}
public class GenericMain {
    public static void main(String[] args) {
        Solution<String> x= new Solution<>();
        x.setFieldName("babu");
        System.out.println(x.getFieldName());
    }
}
