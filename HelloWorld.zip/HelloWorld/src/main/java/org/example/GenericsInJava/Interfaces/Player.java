package org.example.GenericsInJava.Interfaces;

public interface Player {
}
