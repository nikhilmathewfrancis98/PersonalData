package org.example.GenericsInJava.generics;

import org.example.GenericsInJava.Interfaces.Player;

record BaseballPlayer(String name,String position) implements Player {}
record FootballPlayer(String name,String position)implements Player{}

public class GenericMain {
    public static void main(String[] args) {
//      The 2 Baseball teams and the corresponding team members
        SportsTeam<BaseballPlayer> winnersPothu=new SportsTeam<>("Winners Pothumukku( Shaji Pappan) Baseball");

        winnersPothu.addTeamMember(new BaseballPlayer("Shaji Pappan","Master"));
        winnersPothu.addTeamMember(new BaseballPlayer("Arakkal Abu","Right Fielder"));
        winnersPothu.addTeamMember(new BaseballPlayer("Lolan Varghese","Left Fielder"));
        winnersPothu.listTeamMembers();

        SportsTeam<BaseballPlayer> kurukkan=new SportsTeam<>("Kurukkan Moola BBT Baseball");

        kurukkan.addTeamMember(new BaseballPlayer("Balu","Master"));
        kurukkan.addTeamMember(new BaseballPlayer("Babu Mesri","Right Fielder"));
        kurukkan.addTeamMember(new BaseballPlayer(" Baby Jackey","Left Fielder"));
        kurukkan.listTeamMembers();
        scoreResult(winnersPothu,9,kurukkan,5);

//  ==============================================================================================================================

//      The 2 Football teams and the corresponding team members
        SportsTeam<FootballPlayer> afc=new SportsTeam<>("The Argentina United");
        afc.addTeamMember(new FootballPlayer("Tex Walker","Center half forward"));
        afc.addTeamMember(new FootballPlayer("Polo Dibale","Striker"));
        afc.addTeamMember(new FootballPlayer("Lionel Messi","Left Winger"));
        afc.listTeamMembers();
        // Here there is a problem like I can add baseball player to this afc since it's a
//        Football team eg

//        var guthrie=new BaseballPlayer("D Githrie","Center Fielder");
//        afc.addTeamMember(guthrie); // If we add T inside SportsTeam We cannot add this , it will give error
//        afc.listTeamMembers(); // We can see the Baseball player

        SportsTeam<FootballPlayer> bfc = new SportsTeam<>("The Barcelona United");


    }

    public static void scoreResult(SportsTeam team1, int t1Score,
                                   SportsTeam team2, int t2Sore){
        String message= team1.setScore(t1Score,t2Sore);
        // Here we are not receiving the message because we already took above one of the winning team
        team2.setScore(t2Sore,t1Score);
        System.out.printf("%s %s %s %n", team1, message,team2);
    }
}
