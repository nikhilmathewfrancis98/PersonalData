package org.example.GenericsInJava.generics;

import java.util.ArrayList;
import java.util.List;

/**
 *  We are going to comment this class because we are trying to add the
 *  team class for generic usage and use the player Interface so that any
 *  Player teams can be created
 */
public class BaseBallTeam {
    private final String teamName;
    private final List<BaseballPlayer> teamMembers=new ArrayList<>();
    private int totalWins=0;
    private int totalTies=0;
    private int totalLosses=0;

    public BaseBallTeam(String teamName) {
        this.teamName = teamName;
    }
    public void addTeamMember(BaseballPlayer player){
        if (!teamMembers.contains(player)){
            teamMembers.add(player);
        }
    }
    public void listTeamMembers(){
        System.out.println(teamName + " Roster:");
        System.out.println(teamMembers);
    }

    public int ranking(){
        return (totalLosses * 2) + totalTies + 1;
    }

    public String setScore(int ourScore,int theirScore){
        String message = "lost to";
        if (ourScore > theirScore){
            totalWins++;
            message="beat";
        } else if (ourScore == theirScore) {
            totalTies++;
            message="tied";
        }else {
            totalLosses++;
        }
        return message;
    }

    @Override
    public String toString(){
        return teamName + " (Ranked " + ranking() +")";
    }
}
