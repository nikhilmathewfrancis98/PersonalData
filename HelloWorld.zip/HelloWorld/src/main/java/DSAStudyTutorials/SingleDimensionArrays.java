package DSAStudyTutorials;

import java.util.Arrays;

public class SingleDimensionArrays {
    int []arr = null;
    public SingleDimensionArrays(int sizeOfArray){
    arr = new int[sizeOfArray];
        Arrays.fill(arr, Integer.MIN_VALUE);

    }
    public void insert(int location, int valueToBeInserted){
        try{
            if (arr[location] == Integer.MIN_VALUE){ // --> o(1)
                arr[location] = valueToBeInserted;   // --> o(1)
                System.out.println("Successfully inserted");   // --> o(1)
            }else {
                System.out.println("This cell is already occupied");  // --> o(1)
            }
        }catch (ArrayIndexOutOfBoundsException e){
            System.out.println("Invalid Access to the array"+e.getMessage());  // --> o(1)
        }
    }

    public void display(){
        System.out.println(Arrays.toString(arr));
    }

//    Array Traversal
    public void traverseArray(){
        try {
            for (int a : arr)  // --> o(n)
                System.out.println(a);  // --> o(1)
        }catch (NullPointerException e){
            System.out.println("The array does not exists"+e); // --> o(1)
        }
    }

//    Search in an Element i the array
    public void searchElement(int valueToSearch){  // This is linear search
        for (int x:arr)  // --> o(n) worst case if element not found
            if (x == valueToSearch){   // --> o(1)
                System.out.println("Element found : "+x);  // --> o(1)
                return;}
        System.out.println("Element not fount");  // --> o(1)
    }

//    Deleting the value in the array
    public void deleteElement(int  value){ // here we are sending the index
//        If we are sending the value to be deleted we need to do the traversal
        try {
            arr[value] =Integer.MIN_VALUE;
            System.out.println("Successfully deleted");
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Not present in th array"+e);

        }
    }
    public static void main(String[] args) {
        SingleDimensionArrays d=new SingleDimensionArrays(7);
        d.insert(0,10);
        d.insert(1,20);
        d.insert(2,30);
        d.insert(1,0);
        d.insert(12,130);
        d.display();
        d.traverseArray();
        d.deleteElement(1); // here we are provided the index of the element to be deleted
        d.display();

//      Accessing the element
        System.out.println(d.arr[0]);
        d.searchElement(210);
    }
}
